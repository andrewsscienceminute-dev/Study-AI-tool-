(() => {
  'use strict';

  const STORAGE_KEY = 'study-desk-v2';
  const LEGACY_KEY = 'study-desk-v1';
  const EXAMPLE_IDS = new Set(['set-english', 'set-business', 'set-math', 'set-code']);
  const defaults = { lessons: 3, multipleChoice: 7, shortAnswers: 7, longAnswers: 1, longPoints: 3, trueFalse: 0, explain: 3 };
  const appearanceDefaults = { pageStart: '#ffd500', pageEnd: '#ff7900', pageGlowX: 50, pageGlowY: 50, pageGlowRadius: 72, pageBlend: 'glow', pageImageOpacity: 34, headingColor: '#f44b00', tileColor: '#d1c2a0', tileText: '#85847f', cardBg: '#ffad00', cardAccent: '#ff7900', cardText: '#f04a00', cardGlowX: 50, cardGlowY: 50, cardGlowRadius: 72, cardBlend: 'glow', panelColor: '#fffdfb', panelText: '#171311', infoBg: '#ff3b00', infoText: '#111111', settingsBg: '#b3b3b3', settingsText: '#737373', shadowColor: '#704300', shadowDepth: 9 };
  const blendStyles = new Set(['soft', 'glow', 'spotlight', 'wash', 'vivid']);
  const types = {
    review: { label: 'Review', mark: '◔', group: 'List of questions' },
    test: { label: 'Test', mark: '✓', group: 'List of questions' },
    qcards: { label: 'Q cards', mark: '▣', group: 'List of questions' },
    lesson: { label: 'Lesson', mark: '▤', group: 'Slides' },
    'lesson-test': { label: 'Lesson + Test', mark: '▧', group: 'Slides' },
    'slide-analysis': { label: 'Slide analysis', mark: '⌕', group: 'Slides' },
    'math-test': { label: 'Test', cardLabel: 'Math test', mark: '1+1', group: 'Math' },
    'multiple-choice': { label: 'Multiple choice', mark: '◉', group: 'Math' },
    showcase: { label: 'Showcase', mark: '✦', group: 'Math' }
  };
  const palette = [
    { bg: '#ffad00', ink: '#f04a00', className: 'card-gold' },
    { bg: '#12b8e9', ink: '#0754a7', className: 'card-blue' },
    { bg: '#ff321c', ink: '#ef3a58', className: 'card-red' },
    { bg: '#d633c9', ink: '#f07eaf', className: 'card-purple' },
    { bg: '#78bd43', ink: '#34763a', className: 'card-green' },
    { bg: '#ff8800', ink: '#ef5100', className: 'card-orange' }
  ];
  const byId = id => document.getElementById(id);
  const uid = type => `${type}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
  const esc = value => String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  const validHex = value => /^#[0-9a-f]{6}$/i.test(value || '');
  const clampPercent = value => Math.max(4, Math.min(96, Math.round(Number.isFinite(Number(value)) ? Number(value) : 50)));
  const legacyGlowPosition = mode => ({ 'top-down': [50, 22], 'bottom-up': [50, 78], 'left-right': [22, 50], 'right-left': [78, 50], 'corner-tl': [18, 18], 'corner-tr': [82, 18], 'corner-bl': [18, 82], 'corner-br': [82, 82] }[mode] || [50, 50]);
  function normalizeAppearance(raw = {}) {
    const pageLegacy = legacyGlowPosition(raw.pageShade); const cardLegacy = legacyGlowPosition(raw.cardShade);
    const appearance = { ...appearanceDefaults };
    Object.keys(appearanceDefaults).forEach(key => {
      if (key === 'shadowDepth') appearance[key] = Math.max(0, Math.min(20, Number(raw[key] ?? appearanceDefaults[key]) || 0));
      else if (key === 'pageImageOpacity') appearance[key] = Math.max(0, Math.min(85, Number(raw[key] ?? appearanceDefaults[key]) || 0));
      else if (key.endsWith('GlowRadius')) appearance[key] = Math.max(20, Math.min(140, Number(raw[key] ?? appearanceDefaults[key]) || appearanceDefaults[key]));
      else if (key.endsWith('GlowX') || key.endsWith('GlowY')) {
        const legacy = key.startsWith('page') ? pageLegacy : cardLegacy; const axis = key.endsWith('GlowX') ? 0 : 1;
        appearance[key] = clampPercent(raw[key] ?? legacy[axis]);
      } else if (key.endsWith('Blend')) appearance[key] = blendStyles.has(raw[key]) ? raw[key] : appearanceDefaults[key];
      else appearance[key] = validHex(raw[key]) ? raw[key] : appearanceDefaults[key];
    });
    return appearance;
  }
  const colorFor = name => ({ sunrise: palette[0], lagoon: palette[1], lilac: palette[3], coral: palette[2], sage: palette[4], peach: palette[5] }[name] || palette[0]);
  const oldType = format => ({ 'lesson-test': 'lesson-test', lesson: 'lesson', flashcards: 'qcards', quiz: 'test', math: 'math-test', slides: 'lesson', 'slide-analysis': 'slide-analysis' }[format] || 'lesson');

  const shopFrameSpecs = [
    ['Honey Outline','#eab02f','solid',31],['Tangerine Edge','#f47d26','solid',24],['Rose Gold','#d8796c','double',27],['Berry Line','#ad4375','solid',22],['Orchid Trim','#9b69c9','double',31],['Lilac Edge','#9a89d4','solid',35],['Sky Stitch','#3398cf','dashed',25],['Ocean Trim','#167b99','solid',24],['Lagoon Line','#1eaaa0','double',33],['Mint Stitch','#61a878','dashed',28],['Sage Border','#769357','solid',20],['Fern Inlay','#326d4e','double',28],['Lime Pop','#9ebd47','solid',32],['Lemon Trim','#dec34a','dashed',21],['Coral Bead','#e97662','double',35],['Cherry Edge','#d45156','solid',26],['Plum Trim','#774b8d','double',23],['Midnight Line','#384774','solid',33],['Moonlit Stitch','#7785ae','dashed',30],['Ice Blue','#75b7c9','solid',20],['Copper Frame','#ba7045','double',33],['Cocoa Edge','#836049','solid',25],['Sandstone','#c2aa7b','dashed',26],['Pearl Frame','#e0ddd4','double',22],['Snowline','#ffffff','solid',28],['Neon Rose','#ff4ea3','solid',35],['Electric Blue','#3674ff','double',25],['Cyber Lime','#b5d93c','dashed',32],['Holo Violet','#c881ff','double',36],['Galaxy Gold','#fac766','double',23],['Frosted Mint','#b8e6d2','solid',30],['Ocean Foam','#65c9cf','dashed',27],['Star Ruby','#b91f51','double',34],['Royal Blue','#24398d','solid',24],['Prism Silver','#c4c8d1','dashed',29]
  ];
  const shopPatternNames = ['Dot Party','Candy Stripes','Checkerboard','Diagonal Dash','Crosshatch','Orbit Rings','Wave Lines'];
  const shopColorways = [['Citrus','#f5b900'],['Lagoon','#23a6bd'],['Berry','#cd4f7a'],['Meadow','#4d9b67'],['Violet','#8566c5']];
  const shopPatternImages = [
    'radial-gradient(circle,var(--shop-pattern-color) 1.35px,transparent 1.7px)',
    'repeating-linear-gradient(135deg,transparent 0 8px,var(--shop-pattern-color) 9px 11px,transparent 12px 20px)',
    'linear-gradient(90deg,var(--shop-pattern-color) 25%,transparent 25% 75%,var(--shop-pattern-color) 75%),linear-gradient(0deg,var(--shop-pattern-color) 25%,transparent 25% 75%,var(--shop-pattern-color) 75%)',
    'repeating-linear-gradient(45deg,transparent 0 7px,var(--shop-pattern-color) 8px 9px,transparent 10px 17px)',
    'repeating-linear-gradient(0deg,transparent 0 11px,var(--shop-pattern-color) 12px 13px),repeating-linear-gradient(90deg,transparent 0 11px,var(--shop-pattern-color) 12px 13px)',
    'radial-gradient(circle at center,transparent 4px,var(--shop-pattern-color) 5px 6px,transparent 7px)',
    'repeating-radial-gradient(ellipse at 50% 100%,transparent 0 7px,var(--shop-pattern-color) 8px 9px,transparent 10px 15px)'
  ];
  const shopBadgeSpecs = [
    ['Little Spark','✦'],['Sunbeam','☀'],['Crescent Moon','☾'],['Lucky Leaf','❧'],['Daisy Dot','✿'],['Heart Note','♥'],['Tiny Crown','♛'],['Cloud Nine','☁'],['Comet Trail','☄'],['Bookworm','▤'],
    ['Thinking Cap','🎓'],['Top Hat','🎩'],['Bucket Hat','👒'],['Study Beanie','🧢'],['Wizard Hat','🧙'],['Party Hat','🥳'],['Lucky Clover','☘'],['Blue Wave','〰'],['Firefly','✺'],['Snowflake','❄'],
    ['Rainbow','🌈'],['Planet','🪐'],['Butterfly','🦋'],['Cherry','🍒'],['Sunflower','🌻'],['Moon Cat','🐈‍⬛'],['Shooting Star','🌠'],['Friendly Frog','🐸'],['Happy Mushroom','🍄'],['Little Ghost','👻']
  ];
  const coinShopCosmetics = [
    ...shopFrameSpecs.map(([name,color,style,radius],index) => ({ id:`coin-frame-${index+1}`,type:'cosmetic',name,slot:'frame',category:'Frame',currency:'coins',price:40+(index%9)*10,icon:'▣',frameColor:color,frameStyle:style,frameRadius:radius,description:`Add the ${name.toLowerCase()} to every study card.` })),
    ...Array.from({length:35},(_,index) => { const colorway=shopColorways[Math.floor(index/7)]; const kind=index%7; return { id:`coin-pattern-${index+1}`,type:'cosmetic',name:`${colorway[0]} ${shopPatternNames[kind]}`,slot:'pattern',category:'Pattern',currency:'coins',price:35+(index%8)*10,icon:'▦',patternKind:kind,patternColor:colorway[1],description:`A light ${shopPatternNames[kind].toLowerCase()} texture for every study card.` }; }),
    ...shopBadgeSpecs.map(([name,icon],index) => ({ id:`coin-badge-${index+1}`,type:'cosmetic',name,slot:'badge',category:'Cover badge',currency:'coins',price:25+(index%6)*10,icon,description:`Show the ${name.toLowerCase()} on every study card.` }))
  ];
  const premiumCosmetics = [
    ...[['Moon Phase','☾'],['Nova Burst','✹'],['Saturn Ring','🪐'],['Comet Heart','💫'],['Astral Crown','♛']].map(([name,icon],i)=>({id:`premium-celestial-${i+1}`,type:'cosmetic',name,slot:'badge',category:'Cover badge',icon,description:`A celestial mark for every study card.`})),
    ...Array.from({length:5},(_,i)=>({id:`premium-garden-${i+1}`,type:'cosmetic',name:['Fern Fronds','Wildflower','Rain Garden','Mossy Pebbles','Rose Trellis'][i],slot:'pattern',category:'Pattern',icon:'▦',patternKind:[4,0,6,5,1][i],patternColor:['#2d7b59','#db7a9b','#3f9b9b','#668653','#bc4c6d'][i],description:'A botanical texture for every study card.'})),
    ...[['Gilded Leaf','#cb9b39','double',30],['Champagne Edge','#edce8b','solid',25],['Bronze Filigree','#a66a38','double',34],['Opal Inlay','#b1c7c8','dashed',28],['Royal Gold','#f5c542','double',36]].map(([name,color,style,radius],i)=>({id:`premium-gilt-${i+1}`,type:'cosmetic',name,slot:'frame',category:'Frame',icon:'▣',frameColor:color,frameStyle:style,frameRadius:radius,description:'A premium metallic frame for every study card.'})),
    ...Array.from({length:5},(_,i)=>({id:`premium-prism-${i+1}`,type:'cosmetic',name:['Prism Drift','Aurora Glass','Iridescent Lines','Spectrum Spark','Neon Ripple'][i],slot:'pattern',category:'Pattern',icon:'▦',patternKind:[6,2,3,0,5][i],patternColor:['#71cde0','#a787df','#ec71a9','#73d5ac','#ed9ec2'][i],description:'A vivid layered finish for every study card.'})),
    ...[['Royal Seal','♛'],['Golden Laurel','❧'],['Crown Jewel','💎'],['Majestic Star','✶'],['Regal Crest','⚜']].map(([name,icon],i)=>({id:`premium-crown-${i+1}`,type:'cosmetic',name,slot:'badge',category:'Cover badge',icon,description:'A regal mark for every study card.'})),
    ...[['Crown Frame','#9c6bd1','double',34],['Mythic Violet','#67459c','solid',31],['Imperial Rose','#c75b86','double',27],['Starlight Silver','#d7d9e4','dashed',35],['Ember Gold','#ef9941','double',23]].map(([name,color,style,radius],i)=>({id:`premium-royal-${i+1}`,type:'cosmetic',name,slot:'frame',category:'Frame',icon:'▣',frameColor:color,frameStyle:style,frameRadius:radius,description:'A royal frame for every study card.'}))
  ];
  const streakFrameSpecs=[['Meteor Trail','#f26a4f','solid',34],['Moon Rabbit','#a692dd','double',29],['Cloud Pillow','#a7c8e3','solid',36],['Dragon Scale','#3d8868','double',24],['Bubblegum Orbit','#e577b2','dashed',32],['Puddle Jumper','#428db2','solid',26],['Comet Confetti','#f4ac3f','double',37],['Mushroom Ring','#bd756b','dashed',28],['Rainbow Rocket','#8569d1','double',35],['Sleepy Star','#d8bd55','solid',25],['Turtle Shell','#678b57','double',31],['Jellybean Pop','#e94f6a','dashed',34],['Ice-Cream Swirl','#e99bb3','double',27],['Dino Parade','#558a6b','solid',36],['Paper Airplane','#4d94c2','dashed',23],['Gummy Bear','#cf6c88','double',33],['Sunset Skate','#e57d3b','solid',28],['Magic Lantern','#9277bd','double',37],['Starry Pajamas','#576b9d','dashed',30],['Golden Ticket','#d5a337','double',25]];
  const streakPatternSpecs=[['Meteor Sprinkle',0,'#ed684e'],['Moonbeam Check',2,'#927ed0'],['Cloud Puff',5,'#8bb7d8'],['Dragon Scales',3,'#37835e'],['Bubblegum Dots',0,'#df67a5'],['Puddle Ripples',6,'#288eaa'],['Comet Stripes',1,'#eca52e'],['Mushroom Rings',5,'#b86357'],['Rocket Sparks',4,'#755cc4'],['Sleepy Stars',0,'#c9ac44'],['Turtle Trail',6,'#5f8752'],['Jellybean Dash',3,'#e44b68'],['Ice-Cream Checks',2,'#db8ba7'],['Dino Footprints',5,'#4c805f'],['Paper Planes',1,'#3886b6'],['Gummy Swirl',6,'#c65b7b'],['Skateboard Slashes',3,'#df7131'],['Lantern Glow',0,'#8269ad'],['Pajama Plaid',4,'#53628c'],['Treasure Sparkle',0,'#c8982f']];
  const streakBadgeSpecs=[['Cloud Captain','☁'],['Tiny Wizard','🧙'],['Space Cadet','🧑‍🚀'],['Dino Buddy','🦖'],['Sleepy Moon','🌙'],['Puppy Pal','🐶'],['Party Hat','🥳'],['Top Hat Tip','🎩'],['Beanie Buddy','🧢'],['Flower Crown','👑'],['Rocket Pup','🚀'],['Book Dragon','🐉'],['Happy Star','🌟'],['Magic Mushroom','🍄'],['Skate Star','🛹'],['Friendly Ghost','👻'],['Rainbow Buddy','🌈'],['Little Bee','🐝'],['Cool Cactus','🌵'],['Golden Trophy','🏆']];
  const STREAK_COSMETICS=[
    ...streakFrameSpecs.map(([name,color,style,radius],index)=>({id:`streak-frame-${index+1}`,type:'cosmetic',exclusive:true,name,slot:'frame',category:'Streak exclusive',icon:'✦',frameColor:color,frameStyle:style,frameRadius:radius,description:'A streak-only frame for all study cards.'})),
    ...streakPatternSpecs.map(([name,kind,color],index)=>({id:`streak-pattern-${index+1}`,type:'cosmetic',exclusive:true,name,slot:'pattern',category:'Streak exclusive',icon:'✦',patternKind:kind,patternColor:color,description:'A streak-only pattern for all study cards.'})),
    ...streakBadgeSpecs.map(([name,icon],index)=>({id:`streak-badge-${index+1}`,type:'cosmetic',exclusive:true,name,slot:'badge',category:'Streak exclusive',icon,description:'A streak-only badge for all study cards.'}))
  ];
  const STREAK_MILESTONE_PACKS=[
    {id:'streak-pack-100',day:100,name:'Century Celebration',icon:'🎉',contents:[
      {id:'streak-100-frame',type:'cosmetic',exclusive:true,name:'Century Confetti',slot:'frame',category:'Milestone exclusive',icon:'✦',frameColor:'#e4a62c',frameStyle:'double',frameRadius:34,description:'A celebratory double frame for reaching a 100-day streak.'},
      {id:'streak-100-pattern',type:'cosmetic',exclusive:true,name:'Hundred Sparks',slot:'pattern',category:'Milestone exclusive',icon:'✦',patternKind:0,patternColor:'#e4a62c',description:'A golden sparkle pattern from the Century Celebration pack.'},
      {id:'streak-100-badge',type:'cosmetic',exclusive:true,name:'Century Champ',slot:'badge',category:'Milestone exclusive',icon:'🏅',description:'A badge for reaching a 100-day streak.'},
      {id:'streak-100-pattern-2',type:'cosmetic',exclusive:true,name:'Firework Finale',slot:'pattern',category:'Milestone exclusive',icon:'✦',patternKind:4,patternColor:'#dd6e69',description:'A bright firework pattern from the Century Celebration pack.'},
      {id:'streak-100-frame-2',type:'cosmetic',exclusive:true,name:'Party Streamers',slot:'frame',category:'Milestone exclusive',icon:'✦',frameColor:'#7c6ac7',frameStyle:'dashed',frameRadius:28,description:'A playful streamer frame from the Century Celebration pack.'}
    ]},
    {id:'streak-pack-200',day:200,name:'Double-Century Club',icon:'🏆',contents:[
      {id:'streak-200-frame',type:'cosmetic',exclusive:true,name:'Double Orbit',slot:'frame',category:'Milestone exclusive',icon:'✦',frameColor:'#438b9e',frameStyle:'double',frameRadius:36,description:'A bold orbit frame for reaching a 200-day streak.'},
      {id:'streak-200-pattern',type:'cosmetic',exclusive:true,name:'Two Hundred Stars',slot:'pattern',category:'Milestone exclusive',icon:'✦',patternKind:6,patternColor:'#438b9e',description:'A flowing star pattern from the Double-Century Club pack.'},
      {id:'streak-200-badge',type:'cosmetic',exclusive:true,name:'Streak Captain',slot:'badge',category:'Milestone exclusive',icon:'🧭',description:'A badge for reaching a 200-day streak.'},
      {id:'streak-200-pattern-2',type:'cosmetic',exclusive:true,name:'Blue Comet Trail',slot:'pattern',category:'Milestone exclusive',icon:'✦',patternKind:1,patternColor:'#7187d2',description:'A comet pattern from the Double-Century Club pack.'},
      {id:'streak-200-frame-2',type:'cosmetic',exclusive:true,name:'Champion Ribbon',slot:'frame',category:'Milestone exclusive',icon:'✦',frameColor:'#cf775d',frameStyle:'solid',frameRadius:22,description:'A champion ribbon frame from the Double-Century Club pack.'}
    ]},
    {id:'streak-pack-300',day:300,name:'Three-Hundred-Day Legend',icon:'👑',contents:[
      {id:'streak-300-frame',type:'cosmetic',exclusive:true,name:'Legendary Laurel',slot:'frame',category:'Milestone exclusive',icon:'✦',frameColor:'#c69a43',frameStyle:'double',frameRadius:38,description:'A laurel frame for reaching a 300-day streak.'},
      {id:'streak-300-pattern',type:'cosmetic',exclusive:true,name:'Legendary Aurora',slot:'pattern',category:'Milestone exclusive',icon:'✦',patternKind:5,patternColor:'#6a70b5',description:'A shimmering aurora pattern from the Three-Hundred-Day Legend pack.'},
      {id:'streak-300-badge',type:'cosmetic',exclusive:true,name:'Study Legend',slot:'badge',category:'Milestone exclusive',icon:'👑',description:'A badge for reaching a 300-day streak.'},
      {id:'streak-300-pattern-2',type:'cosmetic',exclusive:true,name:'Triumph Waves',slot:'pattern',category:'Milestone exclusive',icon:'✦',patternKind:2,patternColor:'#43a89b',description:'A triumphant wave pattern from the Three-Hundred-Day Legend pack.'},
      {id:'streak-300-frame-2',type:'cosmetic',exclusive:true,name:'Mythic Starline',slot:'frame',category:'Milestone exclusive',icon:'✦',frameColor:'#9b6ec9',frameStyle:'dashed',frameRadius:35,description:'A mythic frame from the Three-Hundred-Day Legend pack.'}
    ]}
  ];
  const shopPacks = [
    {id:'pack-celestial',name:'Starlight Symbols',type:'pack',currency:'starTokens',price:2,icon:'☾',contents:['premium-celestial-1','premium-celestial-2','premium-celestial-3','premium-celestial-4','premium-celestial-5'],description:'Five celestial badges for all of your study cards.'},
    {id:'pack-garden',name:'Botanical Textures',type:'pack',currency:'starTokens',price:2,icon:'❀',contents:['premium-garden-1','premium-garden-2','premium-garden-3','premium-garden-4','premium-garden-5'],description:'Five soft nature patterns to layer across your cards.'},
    {id:'pack-gilded',name:'Gilded Frames',type:'pack',currency:'goldStars',price:1,icon:'♛',contents:['premium-gilt-1','premium-gilt-2','premium-gilt-3','premium-gilt-4','premium-gilt-5'],description:'Five metallic frames with polished, inlaid edges.'},
    {id:'pack-prism',name:'Prism Patterns',type:'pack',currency:'goldStars',price:1,icon:'✧',contents:['premium-prism-1','premium-prism-2','premium-prism-3','premium-prism-4','premium-prism-5'],description:'Five vivid textures for a more advanced layered look.'},
    {id:'pack-crown',name:'Crown Insignias',type:'pack',currency:'crownStars',price:1,icon:'♛',contents:['premium-crown-1','premium-crown-2','premium-crown-3','premium-crown-4','premium-crown-5'],description:'Five rare insignias for your whole study library.'},
    {id:'pack-royal',name:'Royal Frames',type:'pack',currency:'crownStars',price:2,icon:'✦',contents:['premium-royal-1','premium-royal-2','premium-royal-3','premium-royal-4','premium-royal-5'],description:'Five special frames with richer trim and shape.'}
  ];
  const shopAddons = [
    {id:'addon-pattern-layer',name:'Pattern Layer+',type:'addon',behavior:'pattern-layer',currency:'goldStars',price:2,icon:'▦',description:'Unlock a second texture slot so two patterns can blend across every card.'},
    {id:'addon-sticker-stack',name:'Sticker Stack+',type:'addon',behavior:'badge-layer',currency:'crownStars',price:1,icon:'✦',description:'Unlock a second cover badge slot and layer two small marks on every card.'},
    {id:'addon-aurora-motion',name:'Aurora Motion',type:'addon',behavior:'effect',effect:'aurora',currency:'crownStars',price:2,icon:'〰',description:'Add an optional animated light sweep to every study card.'}
  ];
  const SHOP_COSMETICS = [...coinShopCosmetics,...premiumCosmetics,...STREAK_COSMETICS,...STREAK_MILESTONE_PACKS.flatMap(pack=>pack.contents)];
  const SHOP_PRODUCTS = [...SHOP_COSMETICS,...shopPacks,...shopAddons];
  const SHOP_PRODUCT_BY_ID = new Map(SHOP_PRODUCTS.map(item=>[item.id,item]));
  const SHOP_COSMETIC_BY_ID = new Map(SHOP_COSMETICS.map(item=>[item.id,item]));
  const SHOP_CURRENCY = {coins:{label:'Study Coins',single:'Study Coin',icon:'🪙'},starTokens:{label:'Star Tokens',single:'Star Token',icon:'✦'},goldStars:{label:'Gold Stars',single:'Gold Star',icon:'★'},crownStars:{label:'Crown Stars',single:'Crown Star',icon:'♛'}};
  const SHOP_TEST_CODE='GiveMe!000Coin39';
  const STREAK_TEST_COMMAND='AdvanceStreak!';
  const shopVariantColors=[['Poppy','#eb5a69'],['Sunshine','#f5bb38'],['Mint','#53b893'],['Lagoon','#36a8c4'],['Sky','#5487dd'],['Lilac','#9b71d0'],['Bubblegum','#e36ba2'],['Tangerine','#ee8842'],['Fern','#4d8055'],['Cocoa','#8a5d45'],['Peach','#f2a383'],['Periwinkle','#7b91c8'],['Cherry','#bb3f59'],['Lemon','#d6c235'],['Berry','#a64c83'],['Ice','#8bcbd2']];
  const shopVariantGradients=[['Sunrise',['#ff8b4d','#ffd74a']],['Pool Party',['#38c7be','#5385e8']],['Berry Fizz',['#ec6190','#9362cf']],['Meadow Glow',['#9cce57','#26a88b']],['Candy Sky',['#79c8ed','#e592d3']],['Golden Hour',['#d98c2d','#ffe98a']],['Moonlight',['#5366a8','#b1bdf2']],['Firefly',['#e4dd4a','#43a874']],['Coral Reef',['#ee765f','#f5c361']],['Lavender Haze',['#ad83e5','#f0a1cf']]];
  const shopRainbowGradient='linear-gradient(115deg,#ff5964 0%,#ffab45 18%,#ffe34e 35%,#59ca78 53%,#49b7e8 70%,#7666e7 86%,#df6fc4 100%)';
  function normalizeShopInventory(saved={}) {
    const shopOwned=[...new Set((Array.isArray(saved.shopOwned)?saved.shopOwned:[]).filter(id=>SHOP_PRODUCT_BY_ID.has(id)))];
    const shopFavorites=[...new Set((Array.isArray(saved.shopFavorites)?saved.shopFavorites:[]).filter(id=>SHOP_PRODUCT_BY_ID.has(id)))];
    const owned=new Set(shopOwned); const raw=saved.shopEquipped||{}; const shopEquipped={frame:'',pattern:'',badge:'',pattern2:'',badge2:'',effect:''};
    ['frame','pattern','badge'].forEach(slot=>{if(SHOP_COSMETIC_BY_ID.get(raw[slot])?.slot===slot&&owned.has(raw[slot]))shopEquipped[slot]=raw[slot];});
    if(owned.has('addon-pattern-layer')&&SHOP_COSMETIC_BY_ID.get(raw.pattern2)?.slot==='pattern'&&owned.has(raw.pattern2))shopEquipped.pattern2=raw.pattern2;
    if(owned.has('addon-sticker-stack')&&SHOP_COSMETIC_BY_ID.get(raw.badge2)?.slot==='badge'&&owned.has(raw.badge2))shopEquipped.badge2=raw.badge2;
    const effect=SHOP_PRODUCT_BY_ID.get(raw.effect); if(effect?.behavior==='effect'&&owned.has(effect.id))shopEquipped.effect=effect.id;
    const rawVariants=saved.shopVariants&&typeof saved.shopVariants==='object'?saved.shopVariants:{}; const shopVariants={};
    Object.entries(rawVariants).forEach(([id,list])=>{if(!owned.has(id)||!SHOP_COSMETIC_BY_ID.has(id)||!Array.isArray(list))return;shopVariants[id]=list.filter(item=>item&&['color','gradient','rainbow'].includes(item.kind)&&Array.isArray(item.colors)&&item.colors.every(validHex)&&((item.kind==='color'&&item.colors.length===1)||(item.kind==='gradient'&&item.colors.length===2)||(item.kind==='rainbow'&&item.colors.length===0))).map(item=>({id:String(item.id||uid('variant')).slice(0,80),kind:item.kind,label:String(item.label||'Variant').slice(0,40),colors:item.colors}));});
    const rawSelections=saved.shopSelectedVariants&&typeof saved.shopSelectedVariants==='object'?saved.shopSelectedVariants:{}; const shopSelectedVariants={};
    Object.entries(shopVariants).forEach(([id,list])=>{const selected=String(rawSelections[id]||'base');shopSelectedVariants[id]=selected==='base'||list.some(item=>item.id===selected)?selected:'base';});
    return {shopOwned,shopFavorites,shopEquipped,shopVariants,shopSelectedVariants};
  }

  function normalizeSet(raw) {
    const type = types[raw.type] ? raw.type : oldType(raw.format);
    const oldColor = colorFor(raw.color);
    const cover = palette.find(item => item.bg.toLowerCase() === String(raw.coverBg || '').toLowerCase()) || oldColor;
    const notes = typeof raw.notes === 'string' ? raw.notes : '';
    return {
      id: raw.id || uid('set'), title: String(raw.title || 'Study set').slice(0, 60), subject: String(raw.subject || raw.course || '').slice(0, 40),
      unit: String(raw.unit || '').slice(0, 40), type, coverBg: validHex(raw.coverBg) ? raw.coverBg : cover.bg,
      coverAccent: validHex(raw.coverAccent) ? raw.coverAccent : '#ff7900', coverBlend: blendStyles.has(raw.coverBlend) ? raw.coverBlend : 'glow', coverGlowRadius: Math.max(20, Math.min(140, Number(raw.coverGlowRadius ?? 72) || 72)),
      lessonStars: Math.max(1, Math.min(6, Math.round(Number(raw.lessonStars) || 3))),
      rewardedMilestones: { coin50: Boolean(raw.rewardedMilestones?.coin50), star3B: Boolean(raw.rewardedMilestones?.star3B), star5Perfect: Boolean(raw.rewardedMilestones?.star5Perfect), star6Perfect: Boolean(raw.rewardedMilestones?.star6Perfect) },
      ...(() => { const legacy = legacyGlowPosition(raw.coverShade); return { coverGlowX: clampPercent(raw.coverGlowX ?? legacy[0]), coverGlowY: clampPercent(raw.coverGlowY ?? legacy[1]) }; })(),
      coverBackgroundOpacity: Math.max(0, Math.min(75, Number(raw.coverBackgroundOpacity ?? 40))), hasBackgroundImage: Boolean(raw.hasBackgroundImage),
      coverInk: validHex(raw.coverInk) ? raw.coverInk : cover.ink, coverSymbol: String(raw.coverSymbol || '').slice(0, 12), hasCoverImage: Boolean(raw.hasCoverImage),
      folder: raw.folder || '', progress: Math.max(0, Number(raw.progress ?? raw.lessonsDone) || 0), lessonGoal: Math.max(1, Number(raw.lessonGoal ?? raw.settings?.lessons) || 3),
      done: Boolean(raw.done), score: raw.score == null || raw.score === '' ? null : Math.max(0, Math.min(100, Number(raw.score) || 0)),
      notes, lessons: Array.isArray(raw.lessons) ? raw.lessons : [], cards: Array.isArray(raw.cards) ? raw.cards : [],
      questions: Array.isArray(raw.questions) ? raw.questions : [], settings: { ...defaults, ...(raw.settings || {}) },
      sessions: Number(raw.sessions) || 0, lastOpened: Number(raw.lastOpened) || 0, attachment: raw.attachment || null
    };
  }
  function initialState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY) || localStorage.getItem(LEGACY_KEY);
      if (!raw) return { sets: [], folders: [], settings: { ...defaults, variantSpinAnimations:true }, appearance: { ...appearanceDefaults }, pageBackground: false, activityDates: [], coins: 0, starTokens: 0, goldStars: 0, crownStars: 0, streakTestDays:0, streakClaimedDays:[], ...normalizeShopInventory() };
      const saved = JSON.parse(raw);
      const oldFolders = Array.isArray(saved.folders) ? saved.folders : [];
      const folders = oldFolders.filter(folder => !['folder-school', 'folder-personal'].includes(folder.id));
      const sets = (Array.isArray(saved.sets) ? saved.sets : []).filter(set => !EXAMPLE_IDS.has(set.id)).map(normalizeSet);
      return { sets, folders, settings: { ...defaults, variantSpinAnimations:true, ...(saved.defaultSettings || saved.settings || {}) }, appearance: normalizeAppearance(saved.appearance || {}), pageBackground: Boolean(saved.pageBackground), activityDates: Array.isArray(saved.activityDates) ? saved.activityDates : saved.stats?.days || [], coins: Math.max(0, Math.floor(Number(saved.coins) || 0)), starTokens: Math.max(0, Math.floor(Number(saved.starTokens) || 0)), goldStars: Math.max(0, Math.floor(Number(saved.goldStars) || 0)), crownStars: Math.max(0, Math.floor(Number(saved.crownStars) || 0)), streakTestDays:Math.max(0,Math.floor(Number(saved.streakTestDays)||0)), streakClaimedDays:[...new Set((Array.isArray(saved.streakClaimedDays)?saved.streakClaimedDays:[]).map(Number).filter(day=>Number.isInteger(day)&&day>0))], ...normalizeShopInventory(saved) };
    } catch { return { sets: [], folders: [], settings: { ...defaults, variantSpinAnimations:true }, appearance: { ...appearanceDefaults }, pageBackground: false, activityDates: [], coins: 0, starTokens: 0, goldStars: 0, crownStars: 0, streakTestDays:0, streakClaimedDays:[], ...normalizeShopInventory() }; }
  }
  let state = initialState();
  let currentFolder = 'all';
  let selectedType = '';
  let selectedBg = palette[0].bg;
  let selectedAccent = '#ff7900';
  let selectedGlowX = 50;
  let selectedGlowY = 50;
  let selectedGlowRadius = 72;
  let selectedBlend = 'glow';
  let selectedInk = palette[0].ink;
  let selectedSymbol = '';
  let selectedCoverImage = null;
  let selectedCoverPreviewUrl = '';
  let selectedCoverBgImage = null;
  let selectedCoverBgPreviewUrl = '';
  let selectedCoverBgOpacity = 40;
  let pageBackgroundUrl = '';
  let pageBackgroundPreviewUrl = null;
  let selectedPageBackgroundFile = null;
  let clearPageBackground = false;
  let wizardStep = 1;
  let activeSetId = null;
  let activeTab = 'overview';
  let itemEdit = null;
  let qcardIndex = 0;
  let qcardFlipped = false;
  let quiz = null;
  let currentPdfUrl = '';
  const coverImageUrls = new Map();
  const cardBackgroundUrls = new Map();

  const getSet = id => state.sets.find(set => set.id === (id || activeSetId));
  const getFolder = id => state.folders.find(folder => folder.id === id);
  const typeInfo = set => types[set.type] || types.lesson;
  const setProgress = set => set.done ? 100 : Math.min(100, Math.round((set.progress / Math.max(1, set.lessonGoal)) * 100));
  const grade = score => score == null ? '—' : score >= 100 ? 'A++' : score >= 96 ? 'A+' : score >= 92 ? 'A(+)' : score >= 88 ? 'A' : score >= 83 ? 'A(-)' : score >= 80 ? 'A-' : score >= 77 ? 'B+' : score >= 73 ? 'B' : score >= 70 ? 'B-' : score >= 67 ? 'C+' : score >= 63 ? 'C' : score >= 60 ? 'C-' : score >= 57 ? 'D+' : score >= 53 ? 'D' : score >= 50 ? 'D-' : score >= 40 ? 'F+' : score >= 30 ? 'F' : score >= 10 ? 'F-' : score > 0 ? 'i' : '0';

  function shadePaint(first, second, x = 50, y = 50, style = 'glow', radius = 72) {
    const a = validHex(first) ? first : '#ffad00'; const b = validHex(second) ? second : a;
    const point = `${clampPercent(x)}% ${clampPercent(y)}%`;
    const size = `${Math.max(20, Math.min(140, Number(radius) || 72))}% ${Math.max(20, Math.min(140, Number(radius) || 72))}%`;
    switch (blendStyles.has(style) ? style : 'glow') {
      case 'soft': return `radial-gradient(ellipse ${size} at ${point},color-mix(in srgb,${b} 34%,white) 0%,color-mix(in srgb,${b} 75%,white) 18%,${b} 35%,${a} 100%)`;
      case 'spotlight': return `radial-gradient(ellipse ${size} at ${point},color-mix(in srgb,${b} 28%,white) 0%,${b} 8%,${a} 38%,${a} 100%)`;
      case 'wash': return `radial-gradient(ellipse ${size} at ${point},${b} 0%,color-mix(in srgb,${a} 50%,${b}) 35%,${a} 100%)`;
      case 'vivid': return `radial-gradient(ellipse ${size} at ${point},color-mix(in srgb,${b} 16%,white) 0%,${b} 13%,color-mix(in srgb,${a} 20%,${b}) 42%,${a} 86%)`;
      default: return `radial-gradient(ellipse ${size} at ${point},color-mix(in srgb,${b} 45%,white) 0%,color-mix(in srgb,${b} 90%,white) 12%,${a} 82%)`;
    }
  }
  function applyAppearance(source = state.appearance) {
    const appearance = normalizeAppearance(source || {});
    const root = document.documentElement;
    root.style.setProperty('--page-gradient', shadePaint(appearance.pageStart, appearance.pageEnd, appearance.pageGlowX, appearance.pageGlowY, appearance.pageBlend, appearance.pageGlowRadius));
    const pageImage = pageBackgroundPreviewUrl !== null ? pageBackgroundPreviewUrl : pageBackgroundUrl;
    root.style.setProperty('--page-image', pageImage ? `url("${pageImage}")` : 'none');
    root.style.setProperty('--page-image-opacity', String(Math.max(0, Math.min(85, Number(appearance.pageImageOpacity) || 0)) / 100));
    root.style.setProperty('--title-color', appearance.headingColor);
    root.style.setProperty('--tile-color', appearance.tileColor); root.style.setProperty('--tile-text', appearance.tileText);
    root.style.setProperty('--panel-color', appearance.panelColor); root.style.setProperty('--panel-text', appearance.panelText);
    root.style.setProperty('--info-bg', appearance.infoBg); root.style.setProperty('--info-text', appearance.infoText);
    root.style.setProperty('--settings-bg', appearance.settingsBg); root.style.setProperty('--settings-text', appearance.settingsText);
    const depth = Math.max(0, Math.min(20, Number(appearance.shadowDepth) || 0));
    root.style.setProperty('--shadow-color', appearance.shadowColor); root.style.setProperty('--shadow-depth', `${depth}px`);
    root.style.setProperty('--shadow-side', `${Math.round(depth * 1.45)}px`); root.style.setProperty('--shadow-lower', `${Math.round(depth * 1.3)}px`);
    root.style.setProperty('--card-default-paint', shadePaint(appearance.cardBg, appearance.cardAccent, appearance.cardGlowX, appearance.cardGlowY, appearance.cardBlend, appearance.cardGlowRadius));
    root.style.setProperty('--card-default-text', appearance.cardText);
  }
  function setGlowHandle(handle, x, y) {
    const left = clampPercent(x); const top = clampPercent(y);
    handle.style.left = `${left}%`; handle.style.top = `${top}%`;
    handle.setAttribute('aria-valuenow', left);
    handle.setAttribute('aria-valuetext', `${left}% from the left, ${top}% from the top`);
  }
  function syncGlowPad(prefix) {
    const form = byId('settingsForm'); const pad = document.querySelector(`[data-glow-pad="${prefix}"]`); const handle = document.querySelector(`[data-glow-handle="${prefix}"]`);
    if (!form || !pad || !handle) return;
    const x = form.elements[`${prefix}GlowX`].value; const y = form.elements[`${prefix}GlowY`].value;
    const first = prefix === 'page' ? form.elements.pageStart.value : form.elements.cardBg.value;
    const second = prefix === 'page' ? form.elements.pageEnd.value : form.elements.cardAccent.value;
    const style = form.elements[`${prefix}Blend`].value; const radius = form.elements[`${prefix}GlowRadius`].value;
    pad.style.background = shadePaint(first, second, x, y, style, radius); setGlowHandle(handle, x, y); syncBlendPicker(prefix);
  }
  function syncBlendPicker(scope) {
    let style; let first; let second;
    if (scope === 'cover') { style = selectedBlend; first = selectedBg; second = selectedAccent; }
    else {
      const form = byId('settingsForm'); if (!form) return;
      style = form.elements[`${scope}Blend`].value;
      first = scope === 'page' ? form.elements.pageStart.value : form.elements.cardBg.value;
      second = scope === 'page' ? form.elements.pageEnd.value : form.elements.cardAccent.value;
    }
    const radius = scope === 'cover' ? selectedGlowRadius : Number(byId('settingsForm').elements[`${scope}GlowRadius`].value);
    document.querySelectorAll(`[data-blend-picker="${scope}"] .blend-option`).forEach(button => {
      button.classList.toggle('selected', button.dataset.blend === style);
      const sample = button.querySelector('.blend-sample');
      if (sample) sample.style.background = shadePaint(first, second, 50, 50, button.dataset.blend, radius);
    });
  }
  function bindGlowHandle(pad, handle, onChange) {
    const fromPointer = event => { const bounds = pad.getBoundingClientRect(); onChange(clampPercent(100 * (event.clientX - bounds.left) / bounds.width), clampPercent(100 * (event.clientY - bounds.top) / bounds.height)); };
    pad.addEventListener('pointerdown', event => { if (event.button !== 0) return; event.preventDefault(); pad.setPointerCapture(event.pointerId); fromPointer(event); });
    pad.addEventListener('pointermove', event => { if (pad.hasPointerCapture(event.pointerId)) fromPointer(event); });
    pad.addEventListener('pointerup', event => { if (pad.hasPointerCapture(event.pointerId)) pad.releasePointerCapture(event.pointerId); });
    handle.addEventListener('keydown', event => {
      const currentX = Number.parseInt(handle.getAttribute('aria-valuenow'), 10) || 50;
      const currentY = Number.parseInt(handle.getAttribute('aria-valuetext')?.match(/(\d+)% from the top/)?.[1], 10) || 50;
      const amount = event.shiftKey ? 10 : 3; let x = currentX; let y = currentY;
      if (event.key === 'ArrowLeft') x -= amount; else if (event.key === 'ArrowRight') x += amount; else if (event.key === 'ArrowUp') y -= amount; else if (event.key === 'ArrowDown') y += amount; else return;
      event.preventDefault(); onChange(clampPercent(x), clampPercent(y));
    });
  }
  function updateSettingsGlow(prefix, x, y) {
    const form = byId('settingsForm'); form.elements[`${prefix}GlowX`].value = x; form.elements[`${prefix}GlowY`].value = y;
    syncGlowPad(prefix); applyAppearance(appearanceFromForm(form));
  }

  function saveState() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
    catch { toast('Browser storage is full. Export your library before adding more.', true); }
  }
  function openDialog(id) { const dialog = byId(id); if (id === 'settingsModal') document.body.classList.add('settings-open'); if (dialog && !dialog.open) dialog.showModal(); }
  function closeDialog(id) { const dialog = byId(id); if (dialog?.open) dialog.close(); if (id === 'settingsModal') document.body.classList.remove('settings-open'); }
  function toast(message, error = false) {
    const node = document.createElement('div'); node.className = 'toast'; node.textContent = message; if (error) node.style.borderColor = '#bb3f22';
    byId('toastRegion').append(node); setTimeout(() => node.remove(), 2800);
  }
  function dateKey(date = new Date()) { return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`; }
  function streakLength() {
    const days = new Set(state.activityDates);
    let cursor = new Date(); cursor.setHours(0, 0, 0, 0);
    if (!days.has(dateKey(cursor))) cursor.setDate(cursor.getDate() - 1);
    let count = 0;
    while (days.has(dateKey(cursor))) { count++; cursor.setDate(cursor.getDate() - 1); }
    return count + Math.max(0,Math.floor(Number(state.streakTestDays)||0));
  }
  function recordStudy(set) {
    const today = dateKey();
    if (!state.activityDates.includes(today)) state.activityDates.push(today);
    state.activityDates = state.activityDates.slice(-90);
    if (set) { set.sessions = (set.sessions || 0) + 1; set.lastOpened = Date.now(); }
    saveState(); renderStreak();
  }
  function renderStreak() {
    const count = streakLength(); byId('streakValue').textContent = count;
    byId('streakBtn').setAttribute('aria-label', `Daily streak: ${count} ${count === 1 ? 'day' : 'days'}. Open streak details`);
  }
  function streakCurrencyReward(day) {
    if(day%50===0)return {wallet:'crownStars',amount:1,label:'Crown Star',icon:'♛'};
    if(day%10===0)return {wallet:'goldStars',amount:1,label:'Gold Star',icon:'★'};
    if(day%4===0)return {wallet:'starTokens',amount:1,label:'Star Token',icon:'✦'};
    return {wallet:'coins',amount:25+((day*37+11)%76),label:'Study Coins',icon:'🪙'};
  }
  function streakMilestonePackForDay(day) { return STREAK_MILESTONE_PACKS.find(pack=>pack.day===day)||null; }
  function streakExclusiveForDay(day) {
    if(day%5!==0||!STREAK_COSMETICS.length)return null;
    const item=STREAK_COSMETICS[Math.floor(day/5)-1]; return item&&!shopIsOwned(item.id)?item:null;
  }
  function renderStreakRewards(scrollToCurrent=false) {
    const progress=streakLength(); const claimed=new Set(state.streakClaimedDays||[]); const pending=Array.from({length:progress},(_,index)=>index+1).filter(day=>!claimed.has(day)).length;
    byId('streakPendingCount').textContent=`${pending} unclaimed ${pending===1?'reward':'rewards'}`;
    byId('streakClaimAll').disabled=pending===0;
    const lastDay=progress+20; const days=[];
    for(let day=1;day<=lastDay;day++){
      const reward=streakCurrencyReward(day); const exclusive=streakExclusiveForDay(day); const milestonePack=streakMilestonePackForDay(day); const isPast=day<=progress; const isClaimed=claimed.has(day); const classes=['streak-day-card',isPast?'past':'upcoming',isClaimed?'claimed':'',milestonePack?'milestone':'',day===progress?'current':''].filter(Boolean).join(' ');
      const status=isClaimed?'Claimed':isPast?'Claim reward':`In ${day-progress} ${day-progress===1?'day':'days'}`;
      const extra=[day%5===0?`<small class="streak-exclusive-preview">✦ ${isClaimed?'Cosmetic claimed':exclusive?esc(exclusive.name):'Collection bonus'}</small>`:'',milestonePack?`<small class="streak-milestone-preview">${milestonePack.icon} ${isClaimed?'Pack claimed':esc(milestonePack.name)} · ${milestonePack.contents.length} cosmetics</small>`:''].join('');
      days.push(`<article class="${classes}" data-streak-day="${day}"><strong>Day ${day}</strong><span class="streak-day-reward">${reward.icon} ${reward.amount} ${esc(reward.label)}</span>${extra}${isPast?`<button type="button" data-streak-claim="${day}" ${isClaimed?'disabled':''}>${status}</button>`:`<span class="streak-day-upcoming">${status}</span>`}</article>`);
    }
    const wheel=byId('streakWheel'); wheel.innerHTML=days.join('');
    if(scrollToCurrent&&progress){const currentCard=wheel.querySelector('.current');if(currentCard)wheel.scrollLeft=currentCard.offsetLeft;}
  }
  function claimStreakRewards(days,claimAll=false) {
    const progress=streakLength(); const claimed=new Set(state.streakClaimedDays||[]);
    const claimable=[...new Set(days)].filter(day=>Number.isInteger(day)&&day>=1&&day<=progress&&!claimed.has(day));
    if(!claimable.length)return;
    const totals={coins:0,starTokens:0,goldStars:0,crownStars:0}; let cosmeticCount=0; const packNames=[];
    claimable.forEach(day=>{
      const reward=streakCurrencyReward(day); totals[reward.wallet]+=reward.amount;
      const exclusive=streakExclusiveForDay(day);
      if(day%5===0){if(exclusive&&!shopIsOwned(exclusive.id)){state.shopOwned.push(exclusive.id);cosmeticCount++;}else if(!exclusive){totals.coins+=40;}}
      const milestonePack=streakMilestonePackForDay(day);
      if(milestonePack){const newlyAdded=milestonePack.contents.filter(item=>!shopIsOwned(item.id));state.shopOwned.push(...newlyAdded.map(item=>item.id));cosmeticCount+=newlyAdded.length;packNames.push(milestonePack.name);}
      claimed.add(day);
    });
    Object.entries(totals).forEach(([wallet,amount])=>{state[wallet]=Math.max(0,Math.floor(Number(state[wallet])||0))+amount;});
    state.streakClaimedDays=[...claimed].sort((a,b)=>a-b); saveState(); renderCurrencyWallet(); renderStreakRewards();
    const summary=Object.entries(totals).filter(([,amount])=>amount>0).map(([wallet,amount])=>`+${amount} ${amount===1?SHOP_CURRENCY[wallet].single:SHOP_CURRENCY[wallet].label}`);
    if(cosmeticCount)summary.push(`${cosmeticCount} exclusive ${cosmeticCount===1?'cosmetic':'cosmetics'}`);
    if(packNames.length)summary.push(`milestone pack${packNames.length===1?'':'s'}: ${packNames.join(', ')}`);
    const prefix=claimAll?`Claimed all ${claimable.length} past rewards`:`Day ${claimable[0]} claimed`;
    byId('streakRewardStatus').textContent=`${prefix}: ${summary.join(' · ')}.`;
    toast(claimAll?`Claimed ${claimable.length} streak ${claimable.length===1?'reward':'rewards'}.`:`Day ${claimable[0]} reward claimed.`);
  }
  function claimStreakReward(day) { claimStreakRewards([day]); }
  let streakClaimSequencePlaying=false;
  let skipStreakClaimSequence=false;
  function buildStreakRevealQueue(days) {
    const queue=[]; const tierRank={coins:0,cosmetic:1,token:2,gold:3,crown:4};
    const add=(entry)=>queue.push({...entry,order:queue.length});
    days.forEach(day=>{
      const reward=streakCurrencyReward(day);
      const currencyTier={coins:'coins',starTokens:'token',goldStars:'gold',crownStars:'crown'}[reward.wallet];
      add({day,kind:'currency',tier:currencyTier,rank:tierRank[currencyTier],wallet:reward.wallet,amount:reward.amount,title:`+${reward.amount} ${reward.label}`,icon:reward.icon,category:reward.label.toUpperCase(),detail:`Daily reward · Day ${day}`});
      if(day%5===0){
        const exclusive=streakExclusiveForDay(day);
        if(exclusive)add({day,kind:'cosmetic',tier:'cosmetic',rank:tierRank.cosmetic,item:exclusive,title:exclusive.name,icon:exclusive.icon||'✦',category:'STREAK EXCLUSIVE',detail:'Added to My collection'});
        else add({day,kind:'currency',tier:'coins',rank:tierRank.coins,wallet:'coins',amount:40,title:'+40 Study Coins',icon:'🪙',category:'COLLECTION BONUS',detail:`Duplicate cosmetic reward · Day ${day}`});
      }
      const pack=streakMilestonePackForDay(day);
      if(pack)pack.contents.filter(item=>!shopIsOwned(item.id)).forEach(item=>add({day,kind:'cosmetic',tier:'cosmetic',rank:tierRank.cosmetic,item,title:item.name,icon:item.icon||'✦',category:`${pack.name.toUpperCase()} PACK`,detail:'Milestone cosmetic · Added to My collection'}));
    });
    return queue.sort((a,b)=>a.rank-b.rank||a.day-b.day||a.order-b.order);
  }
  function revealStreakReward(reward,index,total) {
    const panel=byId('streakClaimExperience');
    panel.className=`streak-claim-experience tier-${reward.tier}`;
    byId('streakClaimCategory').textContent=reward.category;
    byId('streakClaimProgress').textContent=`${index+1} / ${total}`;
    byId('streakClaimIcon').textContent=reward.icon;
    byId('streakClaimName').textContent=reward.title;
    byId('streakClaimDetail').textContent=reward.detail;
    const percentage=Math.round((index+1)/total*100);
    byId('streakClaimProgressBar').style.width=`${percentage}%`;
    const progress=panel.querySelector('[role="progressbar"]'); progress.setAttribute('aria-valuenow',String(percentage));
    void panel.offsetWidth;
    panel.classList.add('is-revealing');
  }
  async function playStreakClaimSequence(queue,dayCount) {
    if(!queue.length)return;
    streakClaimSequencePlaying=true; skipStreakClaimSequence=false;
    const reducedMotion=window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    const panel=byId('streakClaimExperience'); panel.hidden=false;
    const skipButton=byId('streakClaimSkip'); skipButton.disabled=false; skipButton.textContent='Finish now';
    for(let index=0;index<queue.length;index++){
      if(skipStreakClaimSequence)break;
      const reward=queue[index]; revealStreakReward(reward,index,queue.length);
      const duration=reducedMotion?90:reward.tier==='crown'?1050:reward.tier==='gold'?850:reward.tier==='token'?760:620;
      await new Promise(resolve=>setTimeout(resolve,duration));
    }
    const completedEarly=skipStreakClaimSequence;
    if(completedEarly){
      byId('streakClaimCategory').textContent='COLLECTION COMPLETE'; byId('streakClaimProgress').textContent=`${queue.length} / ${queue.length}`;
      byId('streakClaimIcon').textContent='🎉'; byId('streakClaimName').textContent='All rewards are yours!';
      byId('streakClaimDetail').textContent=`${queue.length} rewards from ${dayCount} days have been added.`;
      byId('streakClaimProgressBar').style.width='100%';
      panel.className='streak-claim-experience tier-crown is-revealing';
      await new Promise(resolve=>setTimeout(resolve,650));
    }
    panel.hidden=true; panel.className='streak-claim-experience';
    streakClaimSequencePlaying=false;
    byId('streakRewardStatus').textContent=`Collected ${dayCount} past ${dayCount===1?'day':'days'} · ${queue.length} rewards added to your wallet and My collection.`;
    toast(`Collected ${queue.length} streak ${queue.length===1?'reward':'rewards'}!`);
  }
  function claimAllStreakRewards() {
    if(streakClaimSequencePlaying)return;
    const progress=streakLength(); const claimed=new Set(state.streakClaimedDays||[]);
    const days=Array.from({length:progress},(_,index)=>index+1).filter(day=>!claimed.has(day));
    const queue=buildStreakRevealQueue(days); if(!queue.length)return;
    queue.forEach(reward=>{
      if(reward.kind==='currency')state[reward.wallet]=Math.max(0,Math.floor(Number(state[reward.wallet])||0))+reward.amount;
      else if(!shopIsOwned(reward.item.id))state.shopOwned.push(reward.item.id);
    });
    state.streakClaimedDays=[...new Set([...(state.streakClaimedDays||[]),...days])].sort((a,b)=>a-b);
    saveState(); renderCurrencyWallet(); renderStreakRewards();
    byId('streakRewardStatus').textContent='';
    void playStreakClaimSequence(queue,days.length);
  }
  function advanceTestStreak() {
    state.streakTestDays=Math.max(0,Math.floor(Number(state.streakTestDays)||0))+1; saveState(); renderStreak();
    const day=streakLength(); byId('shopSearch').value=''; renderShop();
    byId('shopStatus').textContent=`Streak advanced to day ${day}. Open your streak to claim its past reward.`;
    toast(`Streak advanced to day ${day}. Its reward is ready to claim.`);
  }
  function openStreak() {
    const count = streakLength(); byId('streakDialogValue').textContent = count;
    byId('streakRewardStatus').textContent=''; renderStreakRewards(true); openDialog('streakModal');
  }
  function renderCurrencyWallet() {
    byId('shopCoinBalance').textContent = Math.max(0, Math.floor(Number(state.coins) || 0));
    byId('shopStarTokenBalance').textContent = Math.max(0, Math.floor(Number(state.starTokens) || 0));
    byId('shopGoldStarBalance').textContent = Math.max(0, Math.floor(Number(state.goldStars) || 0));
    byId('shopCrownBalance').textContent = Math.max(0, Math.floor(Number(state.crownStars) || 0));
  }
  let shopCategory='all';
  let shopFavoriteOnly=false;
  let shopHasColorOnly=false;
  let shopCostFilters=[];
  let shopSourceFilters=[];
  let shopSortFilter='default';
  let variantSpinPlaying=false;
  function shopPrice(item) { const currency=SHOP_CURRENCY[item.currency]; return `${item.price} ${currency.icon} ${item.price===1?currency.single:currency.label}`; }
  function shopIsOwned(id) { return state.shopOwned.includes(id); }
  function renderShopVariantControls(item) {
    const variants=state.shopVariants[item.id]||[]; const selected=state.shopSelectedVariants[item.id]||'base';
    const options=[`<option value="base" ${selected==='base'?'selected':''}>Original look</option>`,...variants.map(variant=>`<option value="${esc(variant.id)}" ${selected===variant.id?'selected':''}>${esc(variant.label)}</option>`)].join('');
    const colorBalance=Number(state.starTokens)||0; const gradientBalance=Number(state.goldStars)||0; const rainbowBalance=Number(state.crownStars)||0; const hasRainbow=variants.some(variant=>variant.kind==='rainbow');
    return `<div class="shop-variant-controls"><label class="shop-variant-select"><span>Choose a look</span><select data-shop-variant-select="${esc(item.id)}">${options}</select></label><div class="shop-variant-buttons"><button type="button" data-shop-action="variant-color" data-shop-id="${esc(item.id)}" title="Get a random color for 1 Star Token" ${colorBalance<1?'disabled':''}>Color · 1 ✦</button><button type="button" data-shop-action="variant-gradient" data-shop-id="${esc(item.id)}" title="Get a random gradient for 1 Gold Star" ${gradientBalance<1?'disabled':''}>Gradient · 1 ★</button><button type="button" data-shop-action="variant-rainbow" data-shop-id="${esc(item.id)}" title="Unlock rainbow for 1 Crown Star" ${hasRainbow||rainbowBalance<1?'disabled':''}>${hasRainbow?'Rainbow owned':'Rainbow · 1 ♛'}</button></div></div>`;
  }
  function renderShopProduct(item) {
    const owned=shopIsOwned(item.id); const equipped=item.type==='cosmetic'?Object.values(state.shopEquipped).includes(item.id):Boolean(item.type==='addon'&&state.shopEquipped.effect===item.id);
    const favorite=(state.shopFavorites||[]).includes(item.id);
    const variant=owned&&item.type==='cosmetic'?activeShopVariant(item.id):null;
    let previewClass=item.slot==='frame'?'preview-frame':item.slot==='pattern'?'preview-pattern':item.slot==='badge'?'preview-badge':'';
    let previewStyle='';
    if(item.slot==='frame'){const gradient=variant?.kind==='rainbow'?shopRainbowGradient:variant?.kind==='gradient'?`linear-gradient(115deg,${variant.colors[0]},${variant.colors[1]})`:'';if(gradient)previewClass+=' preview-frame-gradient';previewStyle=`--preview-frame-color:${variant?.kind==='color'?variant.colors[0]:item.frameColor};--preview-frame-style:${item.frameStyle};--preview-frame-radius:${Math.min(10,Math.round(item.frameRadius/3))}px;${gradient?`--preview-frame-gradient:${gradient}`:''}`;}
    else if(item.slot==='pattern'){const tint=variant?.kind==='rainbow'?shopRainbowGradient:variant?.kind==='gradient'?`linear-gradient(125deg,${variant.colors[0]},${variant.colors[1]})`:'none';previewStyle=`--shop-pattern-image:${shopPatternImages[item.patternKind]};--shop-pattern-color:${variant?.kind==='color'?variant.colors[0]:item.patternColor};--shop-pattern-tint:${tint}`;}
    else if(item.slot==='badge'&&variant){const color=variant.kind==='color'?variant.colors[0]:'';const surface=variant.kind==='rainbow'?shopRainbowGradient:variant.kind==='gradient'?`linear-gradient(135deg,${variant.colors[0]},${variant.colors[1]})`:color?`color-mix(in srgb,${color} 34%,white)`:'';previewStyle=surface?`--shop-badge-surface:${surface};--shop-badge-border:${variant.colors[0]||'#8c62c2'}`:'';}
    let buttonText='Buy'; let action='purchase'; let disabled=false;
    if(item.type==='cosmetic'&&owned){buttonText=equipped?'Equipped':'Equip';action='equip';disabled=equipped;}
    else if(item.type==='pack'&&owned){buttonText='In collection';action='';disabled=true;}
    else if(item.type==='addon'&&owned&&item.behavior==='effect'){buttonText=equipped?'Active':'Equip';action='equip';disabled=equipped;}
    else if(item.type==='addon'&&owned){buttonText='Unlocked';action='';disabled=true;}
    else if((Number(state[item.currency])||0)<item.price){buttonText=`Need ${item.price-(Number(state[item.currency])||0)} more`;disabled=true;}
    const detail=item.type==='pack'?`${item.description}<span class="shop-pack-count">Includes ${item.contents.length} cosmetics</span>`:item.description;
    const tag=item.type==='pack'?'Pack':item.type==='addon'?'Advanced add-on':item.category;
    const priceText=owned?'In your collection':item.currency?shopPrice(item):'In your collection';
    const variants=item.type==='cosmetic'&&owned&&shopCategory==='collection'?renderShopVariantControls(item):'';
    return `<article class="shop-item ${owned?'is-owned':''}"><div class="shop-item-top"><span class="shop-item-mark ${previewClass}" aria-hidden="true" ${previewStyle?`style="${previewStyle}"`:''}>${esc(item.icon||'✦')}</span><button class="shop-item-favorite ${favorite?'active':''}" type="button" data-shop-favorite="${esc(item.id)}" aria-label="${favorite?'Remove':'Add'} ${esc(item.name)} ${favorite?'from':'to'} favorites" aria-pressed="${favorite}" title="${favorite?'Remove from':'Add to'} favorites">${favorite?'♥':'♡'}</button><span class="shop-item-type">${esc(tag)}</span></div><h3>${esc(item.name)}</h3><p>${detail}</p><div class="shop-item-footer"><strong>${esc(priceText)}</strong><button type="button" data-shop-action="${action}" data-shop-id="${esc(item.id)}" ${disabled?'disabled':''}>${buttonText}</button></div>${variants}</article>`;
  }
  function renderShopSlot(label,slot,items,selected='') {
    const options=[`<option value="">None</option>`,...items.map(item=>`<option value="${esc(item.id)}" ${selected===item.id?'selected':''}>${esc(item.name)}</option>`)].join('');
    return `<label class="shop-slot"><span>${esc(label)}</span><select data-shop-slot="${esc(slot)}">${options}</select></label>`;
  }
  function renderShopLoadout() {
    const ownedCosmetics=state.shopOwned.map(id=>SHOP_COSMETIC_BY_ID.get(id)).filter(Boolean);
    const slotNames={frame:'Frame',pattern:'Pattern',badge:'Badge'};
    const slots=['frame','pattern','badge'];
    if(shopIsOwned('addon-pattern-layer'))slots.push('pattern2');
    if(shopIsOwned('addon-sticker-stack'))slots.push('badge2');
    const html=slots.map(slot=>{const base=slot.replace(/[0-9]/g,'');const label=slot==='pattern2'?'Second pattern':slot==='badge2'?'Second badge':slotNames[base];return renderShopSlot(label,slot,ownedCosmetics.filter(item=>item.slot===base),state.shopEquipped[slot]);});
    const effects=shopAddons.filter(item=>item.behavior==='effect'&&shopIsOwned(item.id));
    if(effects.length)html.push(renderShopSlot('Advanced effect','effect',effects,state.shopEquipped.effect));
    byId('shopLoadout').innerHTML=html.join('');
  }
  function shopProductHasColor(item) { return item.type==='cosmetic'&&(state.shopVariants[item.id]||[]).some(variant=>['color','gradient','rainbow'].includes(variant.kind)); }
  function shopProductCost(item) { return item.currency||shopPacks.find(pack=>pack.contents.includes(item.id))?.currency||'reward'; }
  function shopProductSource(item) {
    if(item.type==='addon')return 'addons';
    if(item.type==='pack'||item.id.startsWith('premium-'))return 'packs';
    if(item.id.startsWith('streak-'))return 'streak';
    return 'shop';
  }
  function renderShop() {
    renderCurrencyWallet(); renderShopLoadout();
    byId('shopHasColorFilter').checked=shopHasColorOnly;
    byId('shopFavoriteFilter').checked=shopFavoriteOnly;
    document.querySelectorAll('input[name="shopCostFilter"]').forEach(input=>{input.checked=shopCostFilters.includes(input.value);});
    document.querySelectorAll('input[name="shopSourceFilter"]').forEach(input=>{input.checked=shopSourceFilters.includes(input.value);});
    document.querySelectorAll('input[name="shopSortFilter"]').forEach(input=>{input.checked=input.value===shopSortFilter;});
    const activeFilterCount=(shopHasColorOnly?1:0)+(shopFavoriteOnly?1:0)+shopCostFilters.length+shopSourceFilters.length+(shopSortFilter==='default'?0:1);
    byId('shopFilterSummary').textContent=activeFilterCount?`${activeFilterCount} selected`:'Any item';
    const filters=[['all','Everything'],['coins','Coin cosmetics · 100'],['frame','Frames'],['pattern','Patterns'],['badge','Badges'],['collection','My collection'],['extras','Packs & add-ons']];
    byId('shopCategories').innerHTML=filters.map(([key,label])=>`<button class="shop-filter ${shopCategory===key?'active':''}" type="button" data-shop-filter="${key}" aria-pressed="${shopCategory===key}">${label}</button>`).join('');
    const query=(byId('shopSearch').value||'').trim().toLowerCase(); let products;
    if(shopCategory==='all')products=[...coinShopCosmetics,...shopPacks,...shopAddons].filter(item=>!shopIsOwned(item.id));
    else if(shopCategory==='coins')products=coinShopCosmetics.filter(item=>!shopIsOwned(item.id));
    else if(shopCategory==='extras')products=[...shopPacks,...shopAddons].filter(item=>!shopIsOwned(item.id));
    else if(shopCategory==='collection')products=state.shopOwned.map(id=>SHOP_PRODUCT_BY_ID.get(id)).filter(Boolean);
    else products=coinShopCosmetics.filter(item=>item.slot===shopCategory&&!shopIsOwned(item.id));
    if(shopHasColorOnly)products=products.filter(shopProductHasColor);
    if(shopFavoriteOnly)products=products.filter(item=>(state.shopFavorites||[]).includes(item.id));
    if(shopCostFilters.length)products=products.filter(item=>shopCostFilters.includes(shopProductCost(item)));
    if(shopSourceFilters.length)products=products.filter(item=>shopSourceFilters.includes(shopProductSource(item)));
    if(shopSortFilter!=='default'){
      const collectionOrder=new Map(state.shopOwned.map((id,index)=>[id,index])); const catalogOrder=new Map(SHOP_PRODUCTS.map((item,index)=>[item.id,index]));
      const order=item=>(shopCategory==='collection'?collectionOrder:catalogOrder).get(item.id)??-1;
      products.sort((a,b)=>shopSortFilter==='newest'?order(b)-order(a):order(a)-order(b));
    }
    products=products.filter(item=>!query||`${item.name} ${item.description} ${item.category||''}`.toLowerCase().includes(query));
    byId('shopResultCount').textContent=`${products.length} ${products.length===1?'item':'items'}`;
    const emptyMessage=shopCategory==='collection'?(query?'No collected items match that search.':'Nothing collected yet. Purchased cosmetics, packs, and add-ons will appear here.'):query?'No unowned shop items match that search. Purchased items are in My collection.':'Everything in this section is already in your collection.';
    byId('shopItems').innerHTML=products.length?products.map(renderShopProduct).join(''):`<p class="shop-empty">${emptyMessage}</p>`;
  }
  function openShop() { shopCategory='all'; byId('shopSearch').value=''; byId('shopStatus').textContent=''; renderShop(); openDialog('shopModal'); }
  function toggleShopFavorite(id) {
    if(!SHOP_PRODUCT_BY_ID.has(id))return;
    const favorites=new Set(state.shopFavorites||[]);
    if(favorites.has(id))favorites.delete(id);else favorites.add(id);
    state.shopFavorites=[...favorites]; saveState(); renderShop();
    byId('shopStatus').textContent=favorites.has(id)?'Added to favorites.':'Removed from favorites.';
  }
  function purchaseShopProduct(id) {
    const item=SHOP_PRODUCT_BY_ID.get(id); if(!item||shopIsOwned(id))return;
    const balance=Math.max(0,Math.floor(Number(state[item.currency])||0));
    if(balance<item.price){const missing=item.price-balance;const currency=SHOP_CURRENCY[item.currency];toast(`You need ${missing} more ${(missing===1?currency.single:currency.label).toLowerCase()}.`,true);return;}
    state[item.currency]=balance-item.price; state.shopOwned.push(id);
    if(item.type==='pack')item.contents.forEach(content=>{if(!shopIsOwned(content))state.shopOwned.push(content);});
    if(item.type==='addon'&&item.behavior==='effect')state.shopEquipped.effect=item.id;
    saveState(); renderShop(); renderDashboard();
    byId('shopStatus').textContent=item.type==='pack'?`${item.name} added ${item.contents.length} cosmetics to your collection.`:`${item.name} added to your collection.`;
    toast(item.type==='pack'?`${item.name} added ${item.contents.length} cosmetics to your collection.`:`${item.name} added to your collection.`);
  }
  function equipShopItem(id) {
    const item=SHOP_PRODUCT_BY_ID.get(id); if(!item||!shopIsOwned(id))return;
    if(item.type==='cosmetic'){state.shopEquipped[item.slot]=id;}
    else if(item.type==='addon'&&item.behavior==='effect'){state.shopEquipped.effect=state.shopEquipped.effect===id?'':id;}
    else return;
    saveState(); renderShop(); renderDashboard();
    byId('shopStatus').textContent=item.type==='cosmetic'?`${item.name} is now on all study cards.`:`${item.name} updated across your study cards.`;
    toast(item.type==='cosmetic'?`${item.name} is now on all study cards.`:`${item.name} updated across your study cards.`);
  }
  function variantReelChoices(kind) {
    if(kind==='color')return shopVariantColors.map(([name,color])=>({name,fill:color,colors:[color]}));
    if(kind==='gradient')return shopVariantGradients.map(([name,colors])=>({name,fill:`linear-gradient(135deg,${colors[0]},${colors[1]})`,colors}));
    return [35,75,115,155,195,235,275,315].map(angle=>({name:'Rainbow',fill:shopRainbowGradient.replace('115deg',`${angle}deg`),colors:[]}));
  }
  async function playVariantSpin(item,variant,kind) {
    const overlay=byId('variantSpinOverlay'); const viewport=byId('variantReelWindow'); const track=byId('variantReelTrack');
    const spinPanel=overlay.querySelector('.variant-spin-panel'); spinPanel.classList.remove('revealed');
    const choices=variantReelChoices(kind); const winnerChoice=choices.find(choice=>choice.colors.join('|')===variant.colors.join('|'))||choices[0];
    const winnerIndex=26; const reel=Array.from({length:winnerIndex},()=>choices[Math.floor(Math.random()*choices.length)]); reel.push(winnerChoice);
    const heading={color:'A surprise color',gradient:'A surprise gradient',rainbow:'A rainbow look'}[kind];
    byId('variantSpinKicker').textContent=`1 ${SHOP_CURRENCY[{color:'starTokens',gradient:'goldStars',rainbow:'crownStars'}[kind]].single.toUpperCase()} · STYLE REVEAL`;
    byId('variantSpinHeading').textContent=`${heading} for ${item.name}`;
    byId('variantResultName').textContent='Spinning…'; byId('variantResultDetail').textContent='Let’s see what you get';
    byId('variantSpinResult').classList.remove('landed');
    track.innerHTML=reel.map((choice,index)=>`<div class="variant-reel-chip ${index===winnerIndex?'target':''}"><span style="background:${esc(choice.fill)}"></span><small>${esc(choice.name)}</small></div>`).join('');
    track.style.transition='none'; track.style.transform='translateX(0px)';
    overlay.hidden=false;
    const winner=track.children[winnerIndex]; const sidePadding=Math.max(0,viewport.clientWidth/2-winner.offsetWidth/2);
    track.style.paddingLeft=`${sidePadding}px`; track.style.paddingRight=`${sidePadding}px`;
    void track.offsetWidth;
    const distance=winner.offsetLeft+winner.offsetWidth/2-viewport.clientWidth/2;
    const reduced=window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    const spinDuration=reduced?850:2850;
    requestAnimationFrame(()=>{track.style.transition=`transform ${spinDuration}ms cubic-bezier(.075,.72,.12,1)`;track.style.transform=`translateX(${-distance}px)`;});
    await new Promise(resolve=>setTimeout(resolve,spinDuration+90));
    winner.classList.add('winner'); overlay.classList.add('landed'); spinPanel.classList.add('revealed');
    byId('variantSpinKicker').textContent='LOOK UNLOCKED'; byId('variantResultName').textContent=variant.label;
    byId('variantResultDetail').textContent=`Added to ${item.name}`;
    const swatch=byId('variantResultSwatch'); swatch.style.background=variant.kind==='rainbow'?shopRainbowGradient:variant.kind==='gradient'?`linear-gradient(135deg,${variant.colors[0]},${variant.colors[1]})`:variant.colors[0];
    await new Promise(resolve=>setTimeout(resolve,700));
  }
  async function buyShopVariant(id,kind) {
    if(variantSpinPlaying)return;
    const item=SHOP_COSMETIC_BY_ID.get(id); if(!item||!shopIsOwned(id))return;
    const currency={color:'starTokens',gradient:'goldStars',rainbow:'crownStars'}[kind]; if(!currency)return;
    const balance=Math.max(0,Math.floor(Number(state[currency])||0));
    if(balance<1){toast(`You need 1 more ${SHOP_CURRENCY[currency].single.toLowerCase()}.`,true);return;}
    const variants=state.shopVariants[id]||(state.shopVariants[id]=[]);
    if(kind==='rainbow'&&variants.some(variant=>variant.kind==='rainbow')){toast('Rainbow is already in this item’s styles.');return;}
    let variant;
    if(kind==='color'){
      const used=new Set(variants.filter(value=>value.kind==='color').map(value=>value.colors[0])); const available=shopVariantColors.filter(value=>!used.has(value[1])); const choice=(available.length?available:shopVariantColors)[Math.floor(Math.random()*(available.length?available:shopVariantColors).length)];
      variant={id:uid('variant'),kind,label:`${choice[0]} color`,colors:[choice[1]]};
    } else if(kind==='gradient'){
      const used=new Set(variants.filter(value=>value.kind==='gradient').map(value=>value.colors.join('|'))); const available=shopVariantGradients.filter(value=>!used.has(value[1].join('|'))); const choice=(available.length?available:shopVariantGradients)[Math.floor(Math.random()*(available.length?available:shopVariantGradients).length)];
      variant={id:uid('variant'),kind,label:`${choice[0]} gradient`,colors:choice[1]};
    } else variant={id:uid('variant'),kind,label:'Rainbow',colors:[]};
    variantSpinPlaying=true; let successMessage='';
    try{
      if(state.settings.variantSpinAnimations!==false)await playVariantSpin(item,variant,kind);
      const currentBalance=Math.max(0,Math.floor(Number(state[currency])||0));
      if(currentBalance<1){toast(`You need 1 more ${SHOP_CURRENCY[currency].single.toLowerCase()}.`,true);return;}
      state[currency]=currentBalance-1; const ownedVariants=state.shopVariants[id]||(state.shopVariants[id]=[]);
      ownedVariants.push(variant); state.shopSelectedVariants[id]=variant.id;
      saveState(); renderShop(); renderDashboard();
      const currencyName=SHOP_CURRENCY[currency].single;
      successMessage=`${variant.label} added to ${item.name} for 1 ${currencyName}.`;
      byId('shopStatus').textContent=successMessage;
    }catch(error){
      toast(error?.message||'The style reveal could not finish.',true);
    }finally{
      byId('variantSpinOverlay').hidden=true; byId('variantSpinOverlay').classList.remove('landed'); variantSpinPlaying=false;
    }
    if(successMessage)toast(`${variant.label} added for 1 ${SHOP_CURRENCY[currency].single}.`);
  }
  function selectShopVariant(id,variantId) {
    if(!shopIsOwned(id)||!SHOP_COSMETIC_BY_ID.has(id))return;
    const exists=variantId==='base'||(state.shopVariants[id]||[]).some(variant=>variant.id===variantId); if(!exists)return;
    state.shopSelectedVariants[id]=variantId; saveState(); renderShop(); renderDashboard(); byId('shopStatus').textContent='Item look updated across all study cards.';
  }
  function activeShopVariant(id) {
    const variantId=state.shopSelectedVariants[id]; return (state.shopVariants[id]||[]).find(variant=>variant.id===variantId)||null;
  }
  function redeemShopTestCode() {
    state.coins=Math.max(0,Math.floor(Number(state.coins)||0))+1000;saveState();
    byId('shopSearch').value='';renderShop();byId('shopStatus').textContent='Test code accepted: +1,000 Study Coins.';toast('Test code accepted: +1,000 Study Coins.');
  }
  function handleShopSearch() { if(byId('shopSearch').value===SHOP_TEST_CODE){redeemShopTestCode();return;} if(byId('shopSearch').value===STREAK_TEST_COMMAND){advanceTestStreak();return;} byId('shopStatus').textContent='';renderShop(); }
  function awardLessonCurrencies(set, score) {
    const earned = []; const ledger = set.rewardedMilestones || (set.rewardedMilestones = {});
    const courseStars = Math.max(1, Math.min(6, Math.round(Number(set.lessonStars) || 1)));
    const payout = courseStars === 6 ? 10 : courseStars;
    const award = (milestone, wallet, condition, label, amount = 1) => {
      if (!condition || ledger[milestone]) return;
      state[wallet] = Math.max(0, Math.floor(Number(state[wallet]) || 0)) + amount;
      ledger[milestone] = true; earned.push(`${amount} ${label}${amount === 1 ? '' : 's'}`);
    };
    award('coin50', 'coins', score >= 50, 'Study Coin', payout);
    award('star3B', 'starTokens', score >= 50, 'Star Token', payout);
    award('star5Perfect', 'goldStars', score >= 75, 'Gold Star', payout);
    award('star6Perfect', 'crownStars', score >= 90, 'Crown Star', payout);
    return earned;
  }
  function renderFolders() {
    const host = byId('folderFilters');
    if (!state.folders.length) { host.innerHTML = ''; return; }
    host.innerHTML = `<button class="filter-chip ${currentFolder === 'all' ? 'active' : ''}" data-folder="all" type="button">All sets (${state.sets.length})</button>` + state.folders.map(folder => `<span class="folder-chip-wrap"><button class="filter-chip ${currentFolder === folder.id ? 'active' : ''}" data-folder="${esc(folder.id)}" type="button"><span class="folder-swatch" style="--folder-color:${validHex(folder.color) ? folder.color : '#b87a3c'}"></span>${esc(folder.name)} (${state.sets.filter(set => set.folder === folder.id).length})</button><button class="folder-options" data-folder-menu="${esc(folder.id)}" type="button" aria-label="${esc(folder.name)} options">···</button></span>`).join('');
  }
  function renderCard(set) {
    const info = typeInfo(set); const color = palette.find(item => item.bg === set.coverBg) || palette[0];
    const progressText = set.done ? 'Done' : `Lesson ${set.progress}/${set.lessonGoal}`;
    const score = set.score == null ? '—' : grade(set.score);
    const paint = shadePaint(set.coverBg, set.coverAccent, set.coverGlowX, set.coverGlowY, set.coverBlend, set.coverGlowRadius);
    const image = coverImageUrls.get(set.id);
    const background = cardBackgroundUrls.get(set.id);
    const frame=SHOP_COSMETIC_BY_ID.get(state.shopEquipped.frame);
    const patterns=[state.shopEquipped.pattern,state.shopEquipped.pattern2].map(id=>SHOP_COSMETIC_BY_ID.get(id)).filter(item=>item?.slot==='pattern');
    const badges=[state.shopEquipped.badge,state.shopEquipped.badge2].map(id=>SHOP_COSMETIC_BY_ID.get(id)).filter(item=>item?.slot==='badge');
    const effect=SHOP_PRODUCT_BY_ID.get(state.shopEquipped.effect);
    const frameVariant=frame?activeShopVariant(frame.id):null; const frameGradient=frameVariant?.kind==='rainbow'?shopRainbowGradient:frameVariant?.kind==='gradient'?`linear-gradient(115deg,${frameVariant.colors[0]},${frameVariant.colors[1]})`:'';
    const frameColor=frameVariant?.kind==='color'?frameVariant.colors[0]:frameGradient?'transparent':frame?.frameColor;
    const frameStyle=frame?`--shop-frame-color:${frameColor};--shop-frame-style:${frame.frameStyle};--shop-frame-radius:${frame.frameRadius}px;--shop-frame-width:${frame.frameStyle==='double'?5:3}px`:'';
    const frameVariantMarkup=frameGradient?`<span class="card-shop-frame-variant" aria-hidden="true" style="--shop-frame-gradient:${frameGradient}"></span>`:'';
    const cosmeticLayers=patterns.map(item=>{const variant=activeShopVariant(item.id);const patternColor=variant?.kind==='color'?variant.colors[0]:item.patternColor;const tint=variant?.kind==='rainbow'?shopRainbowGradient:variant?.kind==='gradient'?`linear-gradient(125deg,${variant.colors[0]},${variant.colors[1]})`:'none';return `<span class="card-shop-pattern" aria-hidden="true" style="--shop-pattern-image:${shopPatternImages[item.patternKind]};--shop-pattern-color:${patternColor};--shop-pattern-tint:${tint}"></span>`;}).join('')+(effect?.behavior==='effect'?`<span class="card-shop-effect shop-effect-${esc(effect.effect)}" aria-hidden="true"></span>`:'');
    const badgeMarkup=badges.map((item,index)=>{const variant=activeShopVariant(item.id);const color=variant?.kind==='color'?variant.colors[0]:'';const surface=variant?.kind==='rainbow'?shopRainbowGradient:variant?.kind==='gradient'?`linear-gradient(135deg,${variant.colors[0]},${variant.colors[1]})`:color?`color-mix(in srgb,${color} 34%,white)`:'';const border=variant?.kind==='rainbow'?'#8c62c2':variant?.colors?.[0]||'';return `<span class="card-shop-badge ${index?'secondary':''}" aria-hidden="true" ${surface?`style="--shop-badge-surface:${surface};--shop-badge-border:${border}"`:''}>${esc(item.icon)}</span>`;}).join('');
    return `<article class="study-card ${color.className} ${set.coverInk === '#ffffff' ? 'text-white' : ''} ${badges.length?'has-shop-badge':''}" style="--cover-bg:${set.coverBg};--cover-paint:${paint};--cover-ink:${validHex(set.coverInk) ? set.coverInk : color.ink};--cover-image-opacity:${Math.max(0, Math.min(75, Number(set.coverBackgroundOpacity) || 0)) / 100};${frameStyle}" data-set-id="${esc(set.id)}" tabindex="0" aria-label="Open ${esc(set.title)}">
      ${background ? `<span class="card-background-image" aria-hidden="true" style="background-image:url('${background}')"></span>` : ''}
      ${cosmeticLayers}${frameVariantMarkup}${badgeMarkup}
      <button class="set-card-menu-button" data-action="card-menu" data-id="${esc(set.id)}" aria-label="Set options" type="button">···</button>
      <div class="set-card-menu" data-menu-for="${esc(set.id)}" hidden><button data-action="start" data-id="${esc(set.id)}">Continue</button><button data-action="restart" data-id="${esc(set.id)}">Restart</button><button data-action="export" data-id="${esc(set.id)}">Export</button><button data-action="stats" data-id="${esc(set.id)}">Show all stats</button><button data-action="rename" data-id="${esc(set.id)}">Rename</button><button data-action="delete" data-id="${esc(set.id)}">Delete</button></div>
      <p class="card-subject">${esc(set.subject || 'Study set')}${set.unit ? `　${esc(set.unit)}` : ''}</p><p class="card-title">${esc(set.title)}</p>
      <div class="card-main">${image ? `<img class="card-middle-image" src="${image}" alt="">` : `<span class="card-symbol">${esc(set.coverSymbol || info.mark)}</span>`}<span class="card-score">${esc(score)}</span><span class="card-percent">${set.score == null ? '' : `${set.score}%`}</span></div>
      <div class="card-bottom"><span class="card-progress">${esc(progressText)}</span><span class="card-format">${esc(info.cardLabel || info.label)}</span></div>
    </article>`;
  }
  function renderDashboard() {
    renderFolders();
    let sets = currentFolder === 'all' ? [...state.sets] : state.sets.filter(set => set.folder === currentFolder);
    sets.sort((a, b) => (b.lastOpened || 0) - (a.lastOpened || 0));
    byId('studyGrid').innerHTML = sets.map(renderCard).join('');
    renderStreak();
  }

  function fillFolderSelect() {
    const select = byId('setFolder'); const old = select.value;
    select.innerHTML = `<option value="">No folder</option>` + state.folders.map(folder => `<option value="${esc(folder.id)}">${esc(folder.name)}</option>`).join('');
    if ([...select.options].some(option => option.value === old)) select.value = old;
  }
  function syncSettingsFields(form) {
    Object.keys(defaults).forEach(key => { const input = form.elements[key]; if (input) input.value = state.settings[key]; });
    if(form.elements.variantSpinAnimations)form.elements.variantSpinAnimations.checked=state.settings.variantSpinAnimations!==false;
    Object.keys(appearanceDefaults).forEach(key => { const input = form.elements[key]; if (input) input.value = state.appearance[key]; });
    byId('pageGlowRadiusValue').value = `${state.appearance.pageGlowRadius}%`; byId('pageGlowRadiusValue').textContent = `${state.appearance.pageGlowRadius}%`;
    byId('cardGlowRadiusValue').value = `${state.appearance.cardGlowRadius}%`; byId('cardGlowRadiusValue').textContent = `${state.appearance.cardGlowRadius}%`;
    byId('shadowDepthValue').textContent = state.appearance.shadowDepth;
    syncGlowPad('page'); syncGlowPad('card'); syncBlendPicker('page'); syncBlendPicker('card');
  }
  function setWizardStep(step) {
    wizardStep = step;
    [1, 2, 3].forEach(index => { byId(`wizardStep${index}`).hidden = index !== step; });
    const titles = ['What do you have?', 'Make a cover', 'Settings'];
    byId('wizardTitle').textContent = titles[step - 1];
    byId('wizardStepLabel').textContent = `STEP ${step} OF 3`;
    document.querySelectorAll('.step-dots span').forEach((dot, index) => dot.classList.toggle('current', index + 1 === step));
    byId('wizardBack').hidden = step === 1;
    byId('wizardNext').hidden = step === 3;
    byId('wizardCreate').hidden = step !== 3;
    updateWizardButtons();
  }
  function updateWizardButtons() {
    if (wizardStep === 1) byId('wizardNext').disabled = !selectedType;
    if (wizardStep === 2) byId('wizardNext').disabled = !byId('setTitle').value.trim();
  }
  function updateCoverPreview() {
    const preview = byId('coverPreview');
    preview.style.background = shadePaint(selectedBg, selectedAccent, selectedGlowX, selectedGlowY, selectedBlend, selectedGlowRadius); preview.style.color = selectedInk;
    byId('coverPreview').style.setProperty('--cover-image-opacity', String(selectedCoverBgOpacity / 100));
    byId('coverPreviewBackground').style.backgroundImage = selectedCoverBgPreviewUrl ? `url("${selectedCoverBgPreviewUrl}")` : 'none';
    byId('previewSubject').textContent = byId('setSubject').value.trim() || 'Subject';
    byId('previewTitle').textContent = byId('setTitle').value.trim() || 'Your set';
    const info = types[selectedType] || types.lesson;
    byId('previewMark').textContent = selectedSymbol || info.mark;
    byId('previewMark').hidden = Boolean(selectedCoverImage);
    byId('previewImage').hidden = !selectedCoverPreviewUrl;
    if (selectedCoverPreviewUrl) byId('previewImage').src = selectedCoverPreviewUrl;
    setGlowHandle(byId('coverGlowHandle'), selectedGlowX, selectedGlowY); syncBlendPicker('cover');
    document.querySelectorAll('.symbol-option').forEach(button => button.classList.toggle('selected', button.dataset.symbol === selectedSymbol));
    byId('previewFoot').textContent = `Lesson 0/${byId('createForm').elements.lessons.value || 3}`;
  }
  function openCreate() {
    const form = byId('createForm'); form.reset();
    if (selectedCoverPreviewUrl) URL.revokeObjectURL(selectedCoverPreviewUrl);
    selectedCoverPreviewUrl = ''; selectedCoverImage = null;
    if (selectedCoverBgPreviewUrl) URL.revokeObjectURL(selectedCoverBgPreviewUrl);
    selectedCoverBgPreviewUrl = ''; selectedCoverBgImage = null; selectedCoverBgOpacity = 40;
    selectedType = ''; selectedBg = state.appearance.cardBg; selectedAccent = state.appearance.cardAccent; selectedInk = state.appearance.cardText; selectedGlowX = state.appearance.cardGlowX; selectedGlowY = state.appearance.cardGlowY; selectedGlowRadius = state.appearance.cardGlowRadius; selectedBlend = state.appearance.cardBlend; selectedSymbol = '';
    byId('coverBgColor').value = selectedBg; byId('coverAccentColor').value = selectedAccent; byId('coverTextColor').value = selectedInk;
    byId('coverGlowRadius').value = selectedGlowRadius; byId('coverGlowRadiusValue').textContent = `${selectedGlowRadius}%`;
    byId('coverImageInput').value = ''; byId('clearCoverImage').hidden = true; byId('previewImage').hidden = true;
    byId('coverBackgroundInput').value = ''; byId('clearCoverBackground').hidden = true; byId('coverBackgroundOpacity').value = '40'; byId('coverBackgroundOpacityValue').textContent = '40%';
    document.querySelectorAll('.type-option').forEach(button => button.classList.remove('selected'));
    Object.keys(defaults).forEach(key => { if (form.elements[key]) form.elements[key].value = state.settings[key]; });
    fillFolderSelect(); setWizardStep(1); updateCoverPreview(); openDialog('createModal');
  }
  function makeSet(values) {
    const set = normalizeSet({
      id: uid('set'), title: values.title.trim(), subject: values.subject.trim(), unit: values.unit.trim(), type: selectedType,
      coverBg: selectedBg, coverAccent: selectedAccent, coverGlowX: selectedGlowX, coverGlowY: selectedGlowY, coverGlowRadius: selectedGlowRadius, coverBackgroundOpacity: selectedCoverBgOpacity, coverBlend: selectedBlend, coverInk: selectedInk, coverSymbol: selectedSymbol, folder: values.folder || '', progress: 0, lessonGoal: Number(values.lessons) || state.settings.lessons,
      settings: { lessons: Number(values.lessons) || 3, multipleChoice: Number(values.multipleChoice) || 0, shortAnswers: Number(values.shortAnswers) || 0, longAnswers: Number(values.longAnswers) || 0, longPoints: Number(values.longPoints) || 1, trueFalse: Number(values.trueFalse) || 0, explain: Number(values.explain) || 3 },
      lessonStars: Number(values.lessonStars) || 3, rewardedMilestones: {}, done: false, score: null, notes: '', lessons: [], cards: [], questions: [], sessions: 0, lastOpened: Date.now()
    });
    state.sets.unshift(set); return set;
  }

  function gradeSettingsForm(form) {
    const formData = new FormData(form); const result = {};
    Object.keys(defaults).forEach(key => result[key] = Math.max(key === 'lessons' || key === 'longPoints' ? 1 : 0, Number(formData.get(key)) || 0));
    return result;
  }
  function appearanceFromForm(form) {
    const data = new FormData(form); const appearance = { ...appearanceDefaults };
    Object.keys(appearanceDefaults).forEach(key => {
      if (key === 'shadowDepth') appearance[key] = Math.max(0, Math.min(20, Number(data.get(key)) || 0));
      else if (key === 'pageImageOpacity') appearance[key] = Math.max(0, Math.min(85, Number(data.get(key)) || 0));
      else if (key.endsWith('GlowRadius')) appearance[key] = Math.max(20, Math.min(140, Number(data.get(key)) || appearanceDefaults[key]));
      else if (key.endsWith('GlowX') || key.endsWith('GlowY')) appearance[key] = clampPercent(data.get(key));
      else if (key.endsWith('Blend')) appearance[key] = blendStyles.has(data.get(key)) ? data.get(key) : appearanceDefaults[key];
      else appearance[key] = validHex(data.get(key)) ? data.get(key) : appearanceDefaults[key];
    });
    return appearance;
  }
  function openSettings() {
    if (pageBackgroundPreviewUrl && pageBackgroundPreviewUrl !== pageBackgroundUrl) URL.revokeObjectURL(pageBackgroundPreviewUrl);
    pageBackgroundPreviewUrl = null; selectedPageBackgroundFile = null; clearPageBackground = false;
    byId('pageBackgroundInput').value = ''; byId('clearPageBackground').hidden = !state.pageBackground;
    syncSettingsFields(byId('settingsForm')); byId('pageImageOpacityValue').textContent = `${state.appearance.pageImageOpacity}%`; openDialog('settingsModal');
  }
  function openFolderDialog() { byId('folderForm').reset(); openDialog('folderModal'); setTimeout(() => byId('folderName').focus(), 20); }

  function openStudy(set, tab = 'overview') {
    if (!set) return;
    activeSetId = set.id; activeTab = tab; set.lastOpened = Date.now(); saveState();
    byId('studyTitle').textContent = set.title;
    byId('studyTypeLabel').textContent = [set.subject, set.unit, typeInfo(set).cardLabel || typeInfo(set).label].filter(Boolean).join(' · ').toUpperCase();
    renderStudy(); openDialog('studyModal'); renderDashboard();
  }
  function renderStudy() {
    const set = getSet(); if (!set) return;
    byId('studyTitle').textContent = set.title;
    if (activeTab === 'review') {
      byId('studyBody').innerHTML = `<div class="study-summary"><span>${esc(typeInfo(set).cardLabel || typeInfo(set).label)}</span><span>${set.progress}/${set.lessonGoal} lessons</span><span>Challenge · ${'★'.repeat(set.lessonStars)}</span><span>${set.sessions || 0} study sessions</span></div>${renderReview(set)}`;
      return;
    }
    const tabList = [['overview', 'Overview'], ['lessons', `Lessons (${set.lessons.length})`], ['qcards', `Q cards (${set.cards.length})`], ['questions', `Questions (${set.questions.length})`], ['practice', 'Test']];
    let html = `<div class="study-summary"><span>${esc(typeInfo(set).cardLabel || typeInfo(set).label)}</span><span>${set.progress}/${set.lessonGoal} lessons</span><span>Challenge · ${'★'.repeat(set.lessonStars)}</span><span>${set.score == null ? 'No score yet' : `${grade(set.score)} · ${set.score}%`}</span><span>${set.sessions || 0} study sessions</span></div><nav class="study-tabs">${tabList.map(([key, label]) => `<button class="study-tab ${activeTab === key ? 'active' : ''}" data-action="tab" data-tab="${key}" type="button">${label}</button>`).join('')}</nav>`;
    if (activeTab === 'overview') html += renderOverview(set);
    if (activeTab === 'lessons') html += renderLessons(set);
    if (activeTab === 'qcards') html += renderQCards(set);
    if (activeTab === 'questions') html += renderQuestions(set);
    if (activeTab === 'practice') html += renderQuiz(set);
    byId('studyBody').innerHTML = html;
  }
  function renderOverview(set) {
    const startLabel = set.type === 'qcards' ? 'Study Q cards' : ['test', 'math-test', 'multiple-choice'].includes(set.type) ? 'Start test' : 'Start review';
    let attachment = '';
    if (set.attachment) attachment = `<div class="content-row"><span class="row-index">PDF</span><div class="row-main"><strong>${esc(set.attachment.name)}</strong><p>Attached reference file</p></div><div class="row-actions"><button data-action="open-pdf">View</button></div></div><div id="pdfViewer" hidden><div class="button-row"><button class="outline-button" data-action="close-pdf">Close PDF</button></div><iframe id="pdfFrame" title="Attached PDF" style="width:100%;height:420px;border:1px solid #888;margin-top:8px"></iframe></div>`;
    return `<div class="study-section"><h3>Lesson notes</h3><textarea class="text-area" id="notesEditor" placeholder="Add your lesson notes here">${esc(set.notes)}</textarea><div class="button-row"><button class="next-button" data-action="save-notes">Save notes</button><button class="outline-button" data-action="start">${startLabel}</button><button class="outline-button" data-action="mark-done">Mark complete</button></div><div class="study-summary"><span>Settings: ${set.settings.lessons} lessons</span><span>${set.settings.multipleChoice} multiple choice</span><span>${set.settings.shortAnswers} short answers</span></div>${attachment}</div>`;
  }
  function renderLessons(set) {
    const content = set.lessons.length ? `<div class="lesson-list">${set.lessons.map((item, index) => `<article class="content-row"><span class="row-index">${index + 1}</span><div class="row-main"><strong>${esc(item.title)}</strong><p>${esc(item.content || '')}</p></div><div class="row-actions"><button data-action="edit-item" data-kind="lesson" data-item-id="${esc(item.id)}">Edit</button><button data-action="delete-item" data-kind="lesson" data-item-id="${esc(item.id)}">×</button></div></article>`).join('')}</div>` : `<p>No lessons added yet.</p>`;
    return `<div class="study-section"><div class="subsection-head"><h3>Lessons</h3><button class="next-button" data-action="add-item" data-kind="lesson">＋ Add lesson</button></div>${content}</div>`;
  }
  function renderQCards(set) {
    if (!set.cards.length) return `<div class="study-section"><div class="subsection-head"><h3>Q cards</h3><button class="next-button" data-action="add-item" data-kind="card">＋ Add Q card</button></div><p>No cards added yet.</p></div>`;
    qcardIndex = Math.min(qcardIndex, set.cards.length - 1); const card = set.cards[qcardIndex];
    return `<div class="study-section"><div class="subsection-head"><h3>Q cards · ${qcardIndex + 1} of ${set.cards.length}</h3><button class="next-button" data-action="add-item" data-kind="card">＋ Add Q card</button></div><div class="qcard-stage"><div class="qcard" role="button" tabindex="0" data-action="flip-card"><strong>${esc(qcardFlipped ? card.back : card.front)}</strong><small>Click to flip · ${qcardFlipped ? 'Answer' : 'Question'}</small></div></div><div class="button-row" style="justify-content:center"><button class="outline-button" data-action="qcard-prev" ${qcardIndex === 0 ? 'disabled' : ''}>← Previous</button><button class="outline-button" data-action="qcard-next" ${qcardIndex === set.cards.length - 1 ? 'disabled' : ''}>Next →</button><button class="plain-button" data-action="edit-item" data-kind="card" data-item-id="${esc(card.id)}">Edit</button><button class="plain-button" data-action="delete-item" data-kind="card" data-item-id="${esc(card.id)}">Delete</button></div></div>`;
  }
  function renderQuestions(set) {
    const content = set.questions.length ? `<div class="question-list">${set.questions.map((question, index) => `<article class="content-row"><span class="row-index">${index + 1}</span><div class="row-main"><strong>${esc(question.text)}</strong><ol class="question-answer" type="A">${question.options.map((option, optionIndex) => `<li>${esc(option)}${question.answer === optionIndex ? ' ✓' : ''}</li>`).join('')}</ol></div><div class="row-actions"><button data-action="edit-item" data-kind="question" data-item-id="${esc(question.id)}">Edit</button><button data-action="delete-item" data-kind="question" data-item-id="${esc(question.id)}">×</button></div></article>`).join('')}</div>` : `<p>No questions added yet. Add questions to make a practice test.</p>`;
    return `<div class="study-section"><div class="subsection-head"><h3>Questions</h3><div class="button-row"><button class="outline-button" data-action="start-quiz">Start test</button><button class="next-button" data-action="add-item" data-kind="question">＋ Add question</button></div></div>${content}</div>`;
  }
  function renderQuiz(set) {
    if (!set.questions.length) return `<div class="study-section quiz-screen"><h3>Practice test</h3><p>Add multiple-choice questions before starting a test.</p><button class="next-button" data-action="add-item" data-kind="question">＋ Add question</button></div>`;
    if (!quiz || quiz.setId !== set.id) quiz = { setId: set.id, index: 0, selected: null, submitted: false, answers: [], complete: false };
    if (quiz.complete) {
      const score = Math.round(100 * quiz.answers.filter(answer => answer.correct).length / set.questions.length);
      return `<div class="study-section quiz-screen quiz-result"><p>TEST COMPLETE</p><h3>Your score</h3><strong>${grade(score)} · ${score}%</strong><p>You got ${quiz.answers.filter(answer => answer.correct).length} of ${set.questions.length} questions right.</p><button class="next-button" data-action="quiz-restart">Try again</button></div>`;
    }
    const question = set.questions[quiz.index];
    return `<div class="study-section quiz-screen"><div class="subsection-head"><h3>Question ${quiz.index + 1} of ${set.questions.length}</h3><span>${quiz.answers.filter(answer => answer.correct).length} correct</span></div><div class="quiz-progress"><span style="width:${100 * (quiz.index + 1) / set.questions.length}%"></span></div><h3>${esc(question.text)}</h3>${question.options.map((option, index) => { const result = quiz.submitted && index === question.answer ? 'correct' : quiz.submitted && index === quiz.selected ? 'wrong' : ''; return `<button class="quiz-option ${quiz.selected === index ? 'selected' : ''} ${result}" data-action="answer" data-answer="${index}" ${quiz.submitted ? 'disabled' : ''}><b>${String.fromCharCode(65 + index)}</b>${esc(option)}</button>`; }).join('')}<div class="button-row" style="justify-content:flex-end"><button class="next-button" data-action="${quiz.submitted ? 'quiz-next' : 'quiz-check'}" ${quiz.selected == null && !quiz.submitted ? 'disabled' : ''}>${quiz.submitted ? quiz.index === set.questions.length - 1 ? 'See score' : 'Next question →' : 'Check answer'}</button></div></div>`;
  }
  function startReview(set = getSet()) {
    if (!set) return;
    reviewIndex = 0; recordStudy(set); activeTab = 'lessons'; openStudy(set, set.lessons.length ? 'review' : 'overview');
    if (!set.lessons.length) toast('Add lesson notes to make a review.');
  }
  function renderReview(set) {
    if (!set.lessons.length) return `<div class="study-section lesson-screen"><h3>Review notes</h3><p>${esc(set.notes || 'Add your lesson notes on the Overview tab.')}</p><button class="next-button" data-action="finish-review">Finish review</button></div>`;
    reviewIndex = Math.min(reviewIndex, set.lessons.length - 1);
    const lesson = set.lessons[reviewIndex];
    return `<div class="study-section lesson-screen"><div class="subsection-head"><h3>Lesson ${reviewIndex + 1} of ${set.lessons.length}</h3><span>${set.progress}/${set.lessonGoal} complete</span></div><div class="quiz-progress"><span style="width:${100 * (reviewIndex + 1) / set.lessons.length}%"></span></div><h3>${esc(lesson.title)}</h3><p>${esc(lesson.content)}</p><div class="button-row" style="justify-content:space-between"><button class="outline-button" data-action="review-prev" ${reviewIndex === 0 ? 'disabled' : ''}>← Previous</button><button class="next-button" data-action="review-next">${reviewIndex === set.lessons.length - 1 ? 'Mark complete ✓' : 'Next lesson →'}</button></div></div>`;
  }
  let reviewIndex = 0;

  function openItem(kind, existing = null) {
    itemEdit = { kind, id: existing?.id || null };
    byId('itemTitle').textContent = existing ? `Edit ${kind === 'card' ? 'Q card' : kind}` : `Add ${kind === 'card' ? 'Q card' : kind}`;
    byId('itemPromptLabel').textContent = kind === 'card' ? 'Question' : kind === 'question' ? 'Question' : 'Lesson title';
    byId('itemAnswerLabel').textContent = kind === 'card' ? 'Answer' : 'Notes';
    byId('itemPrompt').value = kind === 'card' ? existing?.front || '' : kind === 'question' ? existing?.text || '' : existing?.title || '';
    byId('itemAnswer').value = kind === 'card' ? existing?.back || '' : kind === 'lesson' ? existing?.content || '' : '';
    byId('itemAnswer').hidden = kind === 'question'; byId('itemAnswerLabel').hidden = kind === 'question';
    byId('questionOptions').hidden = kind !== 'question';
    document.querySelectorAll('.question-option').forEach((input, index) => { input.value = kind === 'question' ? existing?.options?.[index] || '' : ''; input.required = kind === 'question'; });
    byId('correctChoice').value = String(existing?.answer ?? 0);
    openDialog('itemModal'); setTimeout(() => byId('itemPrompt').focus(), 10);
  }
  function saveItem(event) {
    event.preventDefault(); const set = getSet(); if (!set || !itemEdit) return;
    const { kind, id } = itemEdit; let item;
    if (kind === 'lesson') item = { id: id || uid('lesson'), title: byId('itemPrompt').value.trim(), content: byId('itemAnswer').value.trim() };
    if (kind === 'card') item = { id: id || uid('qcard'), front: byId('itemPrompt').value.trim(), back: byId('itemAnswer').value.trim() };
    if (kind === 'question') item = { id: id || uid('question'), text: byId('itemPrompt').value.trim(), options: [...document.querySelectorAll('.question-option')].map(input => input.value.trim()), answer: Number(byId('correctChoice').value) };
    const list = kind === 'lesson' ? set.lessons : kind === 'card' ? set.cards : set.questions;
    if (id) { const index = list.findIndex(entry => entry.id === id); if (index >= 0) list[index] = item; } else list.push(item);
    if (kind === 'lesson') set.lessonGoal = Math.max(set.lessonGoal, set.lessons.length);
    saveState(); closeDialog('itemModal'); renderStudy(); renderDashboard(); toast(id ? 'Changes saved.' : 'Added to your set.');
  }
  function removeItem(kind, id) {
    const set = getSet(); if (!set) return;
    const list = kind === 'lesson' ? set.lessons : kind === 'card' ? set.cards : set.questions;
    const index = list.findIndex(entry => entry.id === id); if (index >= 0) list.splice(index, 1);
    saveState(); renderStudy(); renderDashboard(); toast('Removed.');
  }

  function startQuiz(set = getSet()) {
    if (!set) return;
    if (!set.questions.length) { activeTab = 'questions'; renderStudy(); toast('Add questions before starting a test.'); return; }
    quiz = { setId: set.id, index: 0, selected: null, submitted: false, answers: [], complete: false };
    recordStudy(set); activeTab = 'practice'; openStudy(set, 'practice');
  }
  function openSetMenu(set) {
    activeSetId = set.id;
    const menu = byId('setContextMenu'); menu.hidden = false;
    menu.innerHTML = `<button data-set-action="start">Continue studying</button><button data-set-action="restart">Restart progress</button><button data-set-action="export">Export set</button><button data-set-action="stats">Show all stats</button><button data-set-action="rename">Rename</button><button data-set-action="delete">Delete</button>`;
  }
  function exportSet(set) { download(`${fileSafe(set.title)}.json`, JSON.stringify(set, null, 2), 'application/json'); toast('Study set exported.'); }
  function exportLibrary() { download('study-tool-library.json', JSON.stringify(state, null, 2), 'application/json'); toast('Library exported.'); }
  function fileSafe(name) { return String(name || 'study-set').replace(/[^a-z0-9_-]+/gi, '-').replace(/^-|-$/g, '') || 'study-set'; }
  function download(name, content, type) { const url = URL.createObjectURL(new Blob([content], { type })); const link = document.createElement('a'); link.href = url; link.download = name; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000); }

  function openDb() {
    return new Promise((resolve, reject) => {
      if (!('indexedDB' in window)) { reject(new Error('This browser cannot save PDF attachments.')); return; }
      const request = indexedDB.open('study-tool-files', 1);
      request.onupgradeneeded = () => request.result.createObjectStore('attachments');
      request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error || new Error('Could not open file storage.'));
    });
  }
  async function storeAttachment(id, file) {
    const db = await openDb();
    return new Promise((resolve, reject) => { const tx = db.transaction('attachments', 'readwrite'); tx.objectStore('attachments').put(file, id); tx.oncomplete = () => { db.close(); resolve(); }; tx.onerror = () => { db.close(); reject(tx.error); }; });
  }
  async function loadAttachment(id) {
    const db = await openDb();
    return new Promise((resolve, reject) => { const request = db.transaction('attachments').objectStore('attachments').get(id); request.onsuccess = () => { db.close(); resolve(request.result); }; request.onerror = () => { db.close(); reject(request.error); }; });
  }
  async function removeAttachment(id) {
    const db = await openDb();
    return new Promise((resolve, reject) => { const tx = db.transaction('attachments', 'readwrite'); tx.objectStore('attachments').delete(id); tx.oncomplete = () => { db.close(); resolve(); }; tx.onerror = () => { db.close(); reject(tx.error); }; });
  }
  async function hydrateCoverImages() {
    const imageSets = state.sets.filter(set => set.hasCoverImage);
    const backgroundSets = state.sets.filter(set => set.hasBackgroundImage);
    await Promise.all([
      ...imageSets.map(async set => { try { const blob = await loadAttachment(`cover:${set.id}`); if (blob) coverImageUrls.set(set.id, URL.createObjectURL(blob)); } catch { /* An optional cover image can be missing. */ } }),
      ...backgroundSets.map(async set => { try { const blob = await loadAttachment(`background:${set.id}`); if (blob) cardBackgroundUrls.set(set.id, URL.createObjectURL(blob)); } catch { /* An optional background image can be missing. */ } }),
      ...(state.pageBackground ? [loadAttachment('theme-background').then(blob => { if (blob) pageBackgroundUrl = URL.createObjectURL(blob); }).catch(() => {})] : [])
    ]);
    applyAppearance(); renderDashboard();
  }
  function clearPdfView() { if (currentPdfUrl) URL.revokeObjectURL(currentPdfUrl); currentPdfUrl = ''; }
  async function showPdf() {
    const set = getSet(); if (!set?.attachment) return;
    try { const blob = await loadAttachment(set.id); if (!blob) throw new Error('PDF is not available in this browser.'); clearPdfView(); currentPdfUrl = URL.createObjectURL(blob); byId('pdfFrame').src = currentPdfUrl; byId('pdfViewer').hidden = false; }
    catch (error) { toast(error.message || 'Could not open this PDF.', true); }
  }

  async function importFile(file) {
    const lower = file.name.toLowerCase();
    if (lower.endsWith('.json')) {
      const parsed = JSON.parse(await file.text());
      if (Array.isArray(parsed.sets)) {
        const folderMap = new Map();
        (parsed.folders || []).forEach(folder => { const copy = { ...folder, id: uid('folder') }; state.folders.push(copy); folderMap.set(folder.id, copy.id); });
        parsed.sets.filter(item => !EXAMPLE_IDS.has(item.id)).forEach(item => state.sets.unshift(normalizeSet({ ...item, id: uid('set'), hasCoverImage: false, hasBackgroundImage: false, folder: folderMap.get(item.folder) || '' })));
      } else {
        const raw = parsed.set || parsed; if (!raw || !raw.title) throw new Error('That file does not contain a Study Tool set.');
        state.sets.unshift(normalizeSet({ ...raw, id: uid('set'), hasCoverImage: false, hasBackgroundImage: false, folder: state.folders.some(folder => folder.id === raw.folder) ? raw.folder : '' }));
      }
      saveState(); renderDashboard(); toast('Study content imported.'); return;
    }
    const set = normalizeSet({ id: uid('set'), title: file.name.replace(/\.(pdf|txt|md)$/i, '').replace(/[-_]/g, ' ') || 'Imported lesson', subject: 'Imported lesson', type: 'lesson', coverBg: palette[0].bg, coverInk: palette[0].ink, lessonGoal: state.settings.lessons, progress: 0, notes: '', lessons: [], cards: [], questions: [], settings: state.settings, lastOpened: Date.now() });
    if (lower.endsWith('.pdf')) {
      await storeAttachment(set.id, file); set.attachment = { name: file.name, type: file.type || 'application/pdf', size: file.size };
    } else {
      const content = await file.text(); set.notes = content; set.lessons.push({ id: uid('lesson'), title: 'Imported lesson', content });
    }
    state.sets.unshift(set); saveState(); renderDashboard(); toast('Lesson imported.');
  }

  function folderAction(id) {
    const folder = getFolder(id); if (!folder) return;
    const choice = prompt(`Folder: ${folder.name}\nType R to rename or D to delete.`); if (!choice) return;
    if (choice.trim().toLowerCase() === 'r') { const name = prompt('New folder name', folder.name); if (name?.trim()) { folder.name = name.trim().slice(0, 40); saveState(); renderDashboard(); } }
    if (choice.trim().toLowerCase() === 'd' && confirm(`Delete “${folder.name}”? Its study sets will remain in All sets.`)) { state.sets.forEach(set => { if (set.folder === id) set.folder = ''; }); state.folders = state.folders.filter(item => item.id !== id); if (currentFolder === id) currentFolder = 'all'; saveState(); renderDashboard(); }
  }

  byId('createBtn').addEventListener('click', openCreate);
  const createPlus = byId('createPlus');
  if (createPlus && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    const schedulePlusSpin = () => setTimeout(() => {
      createPlus.style.setProperty('--plus-angle', Math.random() < .5 ? '-90deg' : '90deg');
      createPlus.classList.remove('plus-spin-once'); void createPlus.offsetWidth; createPlus.classList.add('plus-spin-once');
      schedulePlusSpin();
    }, 24000 + Math.random() * 12000);
    createPlus.addEventListener('animationend', event => { if (event.animationName === 'plus-spin-once') createPlus.classList.remove('plus-spin-once'); });
    schedulePlusSpin();
  }
  byId('settingsBtn').addEventListener('click', openSettings);
  byId('shopBtn').addEventListener('click', openShop);
  byId('shopCategories').addEventListener('click', event => { const button=event.target.closest('[data-shop-filter]'); if(!button)return; shopCategory=button.dataset.shopFilter; renderShop(); });
  byId('shopSearch').addEventListener('input', handleShopSearch);
  byId('shopRefinementMenu').addEventListener('change', event => {
    const input=event.target;
    if(input.id==='shopHasColorFilter')shopHasColorOnly=input.checked;
    else if(input.id==='shopFavoriteFilter')shopFavoriteOnly=input.checked;
    else if(input.name==='shopCostFilter')shopCostFilters=[...document.querySelectorAll('input[name="shopCostFilter"]:checked')].map(control=>control.value);
    else if(input.name==='shopSourceFilter')shopSourceFilters=[...document.querySelectorAll('input[name="shopSourceFilter"]:checked')].map(control=>control.value);
    else if(input.name==='shopSortFilter')shopSortFilter=input.value;
    else return;
    renderShop();
  });
  byId('shopClearFilters').addEventListener('click', () => { shopHasColorOnly=false; shopFavoriteOnly=false; shopCostFilters=[]; shopSourceFilters=[]; shopSortFilter='default'; byId('shopRefinementMenu').open=false; renderShop(); });
  byId('shopItems').addEventListener('click', event => { const favorite=event.target.closest('[data-shop-favorite]'); if(favorite){toggleShopFavorite(favorite.dataset.shopFavorite);return;} const button=event.target.closest('[data-shop-action]'); if(!button||button.disabled)return; if(button.dataset.shopAction==='purchase')purchaseShopProduct(button.dataset.shopId); else if(button.dataset.shopAction==='equip')equipShopItem(button.dataset.shopId); else if(button.dataset.shopAction.startsWith('variant-'))buyShopVariant(button.dataset.shopId,button.dataset.shopAction.slice('variant-'.length)); });
  byId('shopItems').addEventListener('change', event => { const select=event.target.closest('[data-shop-variant-select]'); if(select)selectShopVariant(select.dataset.shopVariantSelect,select.value); });
  byId('shopLoadout').addEventListener('change', event => {
    const select=event.target.closest('[data-shop-slot]'); if(!select)return;
    const slot=select.dataset.shopSlot; const id=select.value;
    if(slot==='effect'){const item=SHOP_PRODUCT_BY_ID.get(id); if(id&&(!shopIsOwned(id)||item?.behavior!=='effect'))return;}
    else {const base=slot.replace(/[0-9]/g,''); const item=SHOP_COSMETIC_BY_ID.get(id); if(id&&(!shopIsOwned(id)||item?.slot!==base))return; if(slot==='pattern2'&&!shopIsOwned('addon-pattern-layer'))return; if(slot==='badge2'&&!shopIsOwned('addon-sticker-stack'))return;}
    state.shopEquipped[slot]=id; saveState(); renderShop(); renderDashboard(); toast(id?'Your shared study look was updated.':'That study-card detail was removed.');
  });
  byId('streakBtn').addEventListener('click', openStreak);
  byId('streakWheel').addEventListener('click', event => { const button=event.target.closest('[data-streak-claim]'); if(button&&!button.disabled)claimStreakReward(Number(button.dataset.streakClaim)); });
  byId('streakClaimAll').addEventListener('click', claimAllStreakRewards);
  byId('streakClaimSkip').addEventListener('click', () => { if(!streakClaimSequencePlaying)return; skipStreakClaimSequence=true; byId('streakClaimSkip').disabled=true; byId('streakClaimSkip').textContent='Finishing…'; });
  byId('streakWheelPrev').addEventListener('click', () => byId('streakWheel').scrollBy({left:-Math.max(220,byId('streakWheel').clientWidth*.75),behavior:'smooth'}));
  byId('streakWheelNext').addEventListener('click', () => byId('streakWheel').scrollBy({left:Math.max(220,byId('streakWheel').clientWidth*.75),behavior:'smooth'}));
  byId('infoBtn').addEventListener('click', () => openDialog('infoModal'));
  byId('aboutBtn').addEventListener('click', () => openDialog('aboutModal'));
  byId('addFolderBtn').addEventListener('click', openFolderDialog);
  byId('importBtn').addEventListener('click', () => byId('fileInput').click());
  byId('exportLibraryBtn').addEventListener('click', exportLibrary);
  byId('fileInput').addEventListener('change', async event => { const file = event.target.files?.[0]; if (!file) return; try { await importFile(file); } catch (error) { toast(error.message || 'Could not import this file.', true); } event.target.value = ''; });
  document.querySelectorAll('[data-close]').forEach(button => button.addEventListener('click', () => closeDialog(button.dataset.close)));
  document.querySelectorAll('dialog.modal').forEach(dialog => dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); }));
   byId('createModal').addEventListener('close', () => { selectedType = ''; if (selectedCoverPreviewUrl) URL.revokeObjectURL(selectedCoverPreviewUrl); if (selectedCoverBgPreviewUrl) URL.revokeObjectURL(selectedCoverBgPreviewUrl); selectedCoverPreviewUrl = ''; selectedCoverBgPreviewUrl = ''; selectedCoverImage = null; selectedCoverBgImage = null; });
   byId('settingsModal').addEventListener('close', () => { if (pageBackgroundPreviewUrl && pageBackgroundPreviewUrl !== pageBackgroundUrl) URL.revokeObjectURL(pageBackgroundPreviewUrl); pageBackgroundPreviewUrl = null; selectedPageBackgroundFile = null; clearPageBackground = false; document.body.classList.remove('settings-open'); applyAppearance(); });
  byId('studyModal').addEventListener('close', clearPdfView);

  document.querySelector('.type-groups').addEventListener('click', event => {
    const button = event.target.closest('[data-type]'); if (!button) return;
    selectedType = button.dataset.type; selectedSymbol = types[selectedType].mark;
    document.querySelectorAll('.type-option').forEach(option => option.classList.toggle('selected', option === button));
    updateCoverPreview();
    updateWizardButtons();
  });
  document.addEventListener('click', event => {
    const button = event.target.closest('.blend-option'); if (!button) return;
    const scope = button.closest('[data-blend-picker]')?.dataset.blendPicker; const style = button.dataset.blend;
    if (!blendStyles.has(style)) return;
    if (scope === 'cover') { selectedBlend = style; updateCoverPreview(); return; }
    if (scope === 'page' || scope === 'card') {
      const form = byId('settingsForm'); form.elements[`${scope}Blend`].value = style;
      syncGlowPad(scope); applyAppearance(appearanceFromForm(form));
    }
  });
  byId('wizardNext').addEventListener('click', () => { if (wizardStep === 1 && selectedType) { setWizardStep(2); updateCoverPreview(); } else if (wizardStep === 2 && byId('setTitle').value.trim()) setWizardStep(3); });
  byId('wizardBack').addEventListener('click', () => setWizardStep(Math.max(1, wizardStep - 1)));
  byId('setTitle').addEventListener('input', () => { updateCoverPreview(); updateWizardButtons(); });
  byId('setSubject').addEventListener('input', updateCoverPreview);
  byId('createForm').elements.lessons.addEventListener('input', updateCoverPreview);
  byId('coverBgColor').addEventListener('input', event => { selectedBg = event.target.value; updateCoverPreview(); });
  byId('coverAccentColor').addEventListener('input', event => { selectedAccent = event.target.value; updateCoverPreview(); });
  byId('coverTextColor').addEventListener('input', event => { selectedInk = event.target.value; updateCoverPreview(); });
  byId('coverGlowRadius').addEventListener('input', event => { selectedGlowRadius = Number(event.target.value); byId('coverGlowRadiusValue').textContent = `${selectedGlowRadius}%`; updateCoverPreview(); });
  bindGlowHandle(byId('coverPreview'), byId('coverGlowHandle'), (x, y) => { selectedGlowX = x; selectedGlowY = y; updateCoverPreview(); });
  byId('symbolGrid').addEventListener('click', event => {
    const button = event.target.closest('[data-symbol]'); if (!button) return;
    selectedSymbol = button.dataset.symbol;
    if (selectedCoverImage) { selectedCoverImage = null; if (selectedCoverPreviewUrl) URL.revokeObjectURL(selectedCoverPreviewUrl); selectedCoverPreviewUrl = ''; byId('coverImageInput').value = ''; byId('clearCoverImage').hidden = true; }
    updateCoverPreview();
  });
  byId('coverImageInput').addEventListener('change', event => {
    const file = event.target.files?.[0]; if (!file) return;
    if (selectedCoverPreviewUrl) URL.revokeObjectURL(selectedCoverPreviewUrl);
    selectedCoverImage = file; selectedCoverPreviewUrl = URL.createObjectURL(file); byId('clearCoverImage').hidden = false; updateCoverPreview();
  });
  byId('clearCoverImage').addEventListener('click', () => { selectedCoverImage = null; if (selectedCoverPreviewUrl) URL.revokeObjectURL(selectedCoverPreviewUrl); selectedCoverPreviewUrl = ''; byId('coverImageInput').value = ''; byId('clearCoverImage').hidden = true; updateCoverPreview(); });
  byId('coverBackgroundInput').addEventListener('change', event => {
    const file = event.target.files?.[0]; if (!file) return;
    if (selectedCoverBgPreviewUrl) URL.revokeObjectURL(selectedCoverBgPreviewUrl);
    selectedCoverBgImage = file; selectedCoverBgPreviewUrl = URL.createObjectURL(file); byId('clearCoverBackground').hidden = false; updateCoverPreview();
  });
  byId('clearCoverBackground').addEventListener('click', () => { selectedCoverBgImage = null; if (selectedCoverBgPreviewUrl) URL.revokeObjectURL(selectedCoverBgPreviewUrl); selectedCoverBgPreviewUrl = ''; byId('coverBackgroundInput').value = ''; byId('clearCoverBackground').hidden = true; updateCoverPreview(); });
  byId('coverBackgroundOpacity').addEventListener('input', event => { selectedCoverBgOpacity = Number(event.target.value); byId('coverBackgroundOpacityValue').textContent = `${selectedCoverBgOpacity}%`; updateCoverPreview(); });
  byId('pageBackgroundInput').addEventListener('change', event => {
    const file = event.target.files?.[0]; if (!file) return;
    if (pageBackgroundPreviewUrl && pageBackgroundPreviewUrl !== pageBackgroundUrl) URL.revokeObjectURL(pageBackgroundPreviewUrl);
    selectedPageBackgroundFile = file; clearPageBackground = false; pageBackgroundPreviewUrl = URL.createObjectURL(file); byId('clearPageBackground').hidden = false;
    applyAppearance(appearanceFromForm(byId('settingsForm')));
  });
  byId('clearPageBackground').addEventListener('click', () => {
    if (pageBackgroundPreviewUrl && pageBackgroundPreviewUrl !== pageBackgroundUrl) URL.revokeObjectURL(pageBackgroundPreviewUrl);
    pageBackgroundPreviewUrl = ''; selectedPageBackgroundFile = null; clearPageBackground = true; byId('pageBackgroundInput').value = ''; byId('clearPageBackground').hidden = true;
    applyAppearance(appearanceFromForm(byId('settingsForm')));
  });
  bindGlowHandle(document.querySelector('[data-glow-pad="page"]'), document.querySelector('[data-glow-handle="page"]'), (x, y) => updateSettingsGlow('page', x, y));
  bindGlowHandle(document.querySelector('[data-glow-pad="card"]'), document.querySelector('[data-glow-handle="card"]'), (x, y) => updateSettingsGlow('card', x, y));
  byId('createForm').addEventListener('submit', async event => {
    event.preventDefault(); if (wizardStep !== 3 || !selectedType) return;
    const form = event.currentTarget; const data = new FormData(form); const imageFile = selectedCoverImage; const backgroundFile = selectedCoverBgImage;
    const set = makeSet({ title: data.get('title'), subject: data.get('subject') || '', unit: data.get('unit') || '', folder: data.get('folder') || '', lessonStars: Number(data.get('lessonStars')) || 3, ...gradeSettingsForm(form) });
    closeDialog('createModal');
    if (imageFile) { try { await storeAttachment(`cover:${set.id}`, imageFile); set.hasCoverImage = true; coverImageUrls.set(set.id, URL.createObjectURL(imageFile)); } catch { toast('Set created, but the image could not be saved.', true); } }
    if (backgroundFile) { try { await storeAttachment(`background:${set.id}`, backgroundFile); set.hasBackgroundImage = true; cardBackgroundUrls.set(set.id, URL.createObjectURL(backgroundFile)); } catch { toast('Set created, but its background image could not be saved.', true); } }
    saveState(); renderDashboard(); openStudy(set); toast('Study set created. Add your first lesson, question, or Q card.');
  });
  byId('folderForm').addEventListener('submit', event => { event.preventDefault(); const name = new FormData(event.currentTarget).get('name').trim(); if (!name) return; if (state.folders.some(folder => folder.name.toLowerCase() === name.toLowerCase())) { toast('That folder already exists.', true); return; } const folder = { id: uid('folder'), name: name.slice(0, 40), color: palette[state.folders.length % palette.length].bg }; state.folders.push(folder); saveState(); renderDashboard(); closeDialog('folderModal'); toast('Folder added.'); });
  byId('settingsForm').addEventListener('input', event => {
    if (event.target.name === 'shadowDepth') byId('shadowDepthValue').textContent = event.target.value;
    if (event.target.name === 'pageGlowRadius' || event.target.name === 'cardGlowRadius') byId(`${event.target.name}Value`).textContent = `${event.target.value}%`;
    if (event.target.name === 'pageImageOpacity') byId('pageImageOpacityValue').textContent = `${event.target.value}%`;
    syncGlowPad('page'); syncGlowPad('card'); applyAppearance(appearanceFromForm(event.currentTarget));
  });
  byId('settingsForm').addEventListener('submit', async event => {
    event.preventDefault(); const form = event.currentTarget; let imageSaveFailed = false;
    if (selectedPageBackgroundFile) {
      try { await storeAttachment('theme-background', selectedPageBackgroundFile); if (pageBackgroundUrl) URL.revokeObjectURL(pageBackgroundUrl); pageBackgroundUrl = URL.createObjectURL(selectedPageBackgroundFile); state.pageBackground = true; }
      catch { imageSaveFailed = true; }
    } else if (clearPageBackground) {
      try { await removeAttachment('theme-background'); if (pageBackgroundUrl) URL.revokeObjectURL(pageBackgroundUrl); pageBackgroundUrl = ''; state.pageBackground = false; }
      catch { imageSaveFailed = true; }
    }
    pageBackgroundPreviewUrl = null; selectedPageBackgroundFile = null; clearPageBackground = false;
    state.settings = { ...gradeSettingsForm(form), variantSpinAnimations:form.elements.variantSpinAnimations.checked }; state.appearance = appearanceFromForm(form); applyAppearance(); saveState(); closeDialog('settingsModal');
    toast(imageSaveFailed ? 'Settings saved, but the background image could not be updated.' : 'Settings saved.', imageSaveFailed);
  });
  byId('studyBody').addEventListener('click', event => {
    const button = event.target.closest('[data-action]'); if (!button) return;
    const set = getSet(); if (!set) return;
    const action = button.dataset.action;
    if (action === 'tab') { activeTab = button.dataset.tab; if (activeTab === 'practice') quiz = { setId: set.id, index: 0, selected: null, submitted: false, answers: [], complete: false }; renderStudy(); }
    if (action === 'save-notes') { set.notes = byId('notesEditor').value; saveState(); toast('Notes saved.'); }
    if (action === 'add-item') openItem(button.dataset.kind);
    if (action === 'edit-item') { const kind = button.dataset.kind; const list = kind === 'lesson' ? set.lessons : kind === 'card' ? set.cards : set.questions; openItem(kind, list.find(item => item.id === button.dataset.itemId)); }
    if (action === 'delete-item') removeItem(button.dataset.kind, button.dataset.itemId);
    if (action === 'start') { if (set.type === 'qcards') { recordStudy(set); activeTab = 'qcards'; openStudy(set, 'qcards'); } else if (['test', 'math-test', 'multiple-choice'].includes(set.type)) startQuiz(set); else startReview(set); }
    if (action === 'mark-done' || action === 'finish-review') { set.done = true; set.progress = set.lessonGoal; saveState(); renderStudy(); renderDashboard(); toast('Marked complete. Nice work!'); }
    if (action === 'start-quiz') startQuiz(set);
    if (action === 'flip-card') { qcardFlipped = !qcardFlipped; renderStudy(); }
    if (action === 'qcard-prev') { qcardIndex = Math.max(0, qcardIndex - 1); qcardFlipped = false; renderStudy(); }
    if (action === 'qcard-next') { qcardIndex = Math.min(set.cards.length - 1, qcardIndex + 1); qcardFlipped = false; renderStudy(); }
    if (action === 'answer' && !quiz?.submitted) { quiz.selected = Number(button.dataset.answer); renderStudy(); }
    if (action === 'quiz-check' && quiz?.selected != null) { const question = set.questions[quiz.index]; quiz.submitted = true; quiz.answers.push({ correct: quiz.selected === question.answer }); renderStudy(); }
    if (action === 'quiz-next') {
      if (quiz.index < set.questions.length - 1) { quiz.index++; quiz.selected = null; quiz.submitted = false; renderStudy(); }
      else {
        quiz.complete = true; set.score = Math.round(100 * quiz.answers.filter(answer => answer.correct).length / set.questions.length); set.progress = Math.max(1, set.progress);
        const earned = awardLessonCurrencies(set, set.score); saveState(); renderStudy(); renderDashboard();
        if (earned.length) { renderCurrencyWallet(); toast(`You earned ${earned.join(', ')}!`); }
      }
    }
    if (action === 'quiz-restart') startQuiz(set);
    if (action === 'review-prev') { reviewIndex = Math.max(0, reviewIndex - 1); renderStudy(); }
    if (action === 'review-next') { if (reviewIndex < set.lessons.length - 1) { reviewIndex++; renderStudy(); } else { set.progress = Math.max(set.progress, set.lessons.length); set.done = set.progress >= set.lessonGoal; saveState(); activeTab = 'overview'; renderStudy(); renderDashboard(); toast('Review complete.'); } }
    if (action === 'open-pdf') showPdf();
    if (action === 'close-pdf') { clearPdfView(); byId('pdfFrame').src = 'about:blank'; byId('pdfViewer').hidden = true; }
  });
  byId('studyBody').addEventListener('keydown', event => { if (event.target.matches('.qcard') && (event.key === 'Enter' || event.key === ' ')) { event.preventDefault(); qcardFlipped = !qcardFlipped; renderStudy(); } });
  byId('itemForm').addEventListener('submit', saveItem);
  byId('setMenuBtn').addEventListener('click', () => { const menu = byId('setContextMenu'); if (menu.hidden) openSetMenu(getSet()); else menu.hidden = true; });
  byId('setContextMenu').addEventListener('click', async event => {
    const button = event.target.closest('[data-set-action]'); if (!button) return;
    const set = getSet(); const action = button.dataset.setAction; byId('setContextMenu').hidden = true;
    if (action === 'start') { if (['test', 'math-test', 'multiple-choice'].includes(set.type)) startQuiz(set); else startReview(set); }
    if (action === 'restart' && confirm('Restart this study set’s progress?')) { set.done = false; set.progress = 0; set.score = null; saveState(); renderStudy(); renderDashboard(); }
    if (action === 'export') exportSet(set);
    if (action === 'stats') { toast(`${set.sessions || 0} study sessions · ${set.score == null ? 'No test score yet' : `latest score ${set.score}%`}`); }
    if (action === 'rename') { const title = prompt('Study set name', set.title); if (title?.trim()) { set.title = title.trim().slice(0, 60); saveState(); renderStudy(); renderDashboard(); } }
    if (action === 'delete' && confirm(`Delete “${set.title}”?`)) { if (set.attachment) { try { await removeAttachment(set.id); } catch {} } try { await removeAttachment(`cover:${set.id}`); await removeAttachment(`background:${set.id}`); } catch {} if (coverImageUrls.has(set.id)) URL.revokeObjectURL(coverImageUrls.get(set.id)); if (cardBackgroundUrls.has(set.id)) URL.revokeObjectURL(cardBackgroundUrls.get(set.id)); coverImageUrls.delete(set.id); cardBackgroundUrls.delete(set.id); state.sets = state.sets.filter(item => item.id !== set.id); closeDialog('studyModal'); saveState(); renderDashboard(); }
  });
  byId('studyGrid').addEventListener('click', event => {
    const button = event.target.closest('[data-action]'); const card = event.target.closest('.study-card');
    if (button) {
      const set = getSet(button.dataset.id); if (!set) return;
      if (button.dataset.action === 'card-menu') { const menu = card.querySelector('.set-card-menu'); const shouldOpen = menu.hidden; document.querySelectorAll('.set-card-menu').forEach(item => item.hidden = true); menu.hidden = !shouldOpen; event.stopPropagation(); return; }
      const action = button.dataset.action;
      if (action === 'start') { if (['test', 'math-test', 'multiple-choice'].includes(set.type)) startQuiz(set); else if (set.type === 'qcards') { recordStudy(set); openStudy(set, 'qcards'); } else startReview(set); }
      if (action === 'restart' && confirm('Restart this study set’s progress?')) { set.done = false; set.progress = 0; set.score = null; saveState(); renderDashboard(); }
      if (action === 'export') exportSet(set);
      if (action === 'stats') toast(`${set.sessions || 0} study sessions · ${set.score == null ? 'No test score yet' : `latest score ${set.score}%`}`);
      if (action === 'rename') { const title = prompt('Study set name', set.title); if (title?.trim()) { set.title = title.trim().slice(0, 60); saveState(); renderDashboard(); } }
      if (action === 'delete' && confirm(`Delete “${set.title}”?`)) { if (coverImageUrls.has(set.id)) URL.revokeObjectURL(coverImageUrls.get(set.id)); if (cardBackgroundUrls.has(set.id)) URL.revokeObjectURL(cardBackgroundUrls.get(set.id)); coverImageUrls.delete(set.id); cardBackgroundUrls.delete(set.id); removeAttachment(`cover:${set.id}`).catch(() => {}); removeAttachment(`background:${set.id}`).catch(() => {}); state.sets = state.sets.filter(item => item.id !== set.id); saveState(); renderDashboard(); }
      return;
    }
    if (card) openStudy(getSet(card.dataset.setId));
  });
  byId('studyGrid').addEventListener('keydown', event => { if (event.target.matches('.study-card') && (event.key === 'Enter' || event.key === ' ')) { event.preventDefault(); openStudy(getSet(event.target.dataset.setId)); } });
  byId('folderFilters').addEventListener('click', event => { const options = event.target.closest('[data-folder-menu]'); if (options) { folderAction(options.dataset.folderMenu); return; } const button = event.target.closest('[data-folder]'); if (button) { currentFolder = button.dataset.folder; renderDashboard(); } });

  applyAppearance();
  renderDashboard();
  hydrateCoverImages();
})();
