STUDY TOOL

Open index.html in a modern web browser. It is a single-page app; its dialogs stay in the same tab.

Create a study set as Review, Test, Q cards, Lesson, Lesson + Test, Slide analysis, Math test, Multiple choice, or Showcase. The create flow has an optional source-file step. Select multiple TXT/Markdown files and PDFs together: text is combined into the prompt, while PDFs are attached separately to ChatGPT and kept as references in the new set. Copy the prepared prompt into ChatGPT, then paste its JSON reply back into the app. The app turns the reply into native lesson entries, flip-to-reveal Q cards, or quiz questions and returns you to the create flow to choose a name and cover. JSON library files are imported separately. This browser-only app does not accept API keys; use the prompt path instead. Choose “Add PDF as reference only” to keep PDFs without generating content. The prompt treats files as source material, not instructions.

Study dates build your streak counter. Claim streak rewards for coins, Star Tokens, Gold Stars, Crown Stars, and exclusive cosmetics. Earn an extra 100 Study Coins every 7 days; the weekly bonus increases by 25 coins each week, up to 500. The wheel shows 20 days ahead and keeps past rewards claimable. Every 5 days includes an exclusive cosmetic; days 100, 200, and 300 unlock special 5-item packs. Use Claim all to collect every past unclaimed streak reward. Enter AdvanceStreak! in the Shop search to simulate a streak day.

Choose custom colors for each new set’s background, accent, and text. Pick one of five blend looks, drag the glow to place it, and adjust its radius. Choose a center symbol from the built-in library or upload your own. Add a separate background image to a set cover or the page. Settings keeps basic colors and study defaults easy to reach; less-used color, shadow, image, and library controls are under Advanced options.

The Shop includes 100 Study Coin cosmetics, including frames, patterns, hats, and playful badges. Bought items leave the shop sections and appear in My collection. Use Visit the Shop while creating a set to browse or buy items, then equip owned cosmetics by section. New sets start with no Shop cosmetics; copying your saved Shop look is optional. Packs grant groups of cosmetics, and add-ons unlock extra layers and effects. Quiz results and guided lesson answers award Star Tokens at 50%+, Gold Stars at 75%+, and Crown Stars at 90%. A 1–5 star course pays that many of each earned currency; a 6 star course pays 10. Enter GiveMe!000Coin39 in the Shop search to add 1,000 Study Coins for testing.

The streak badge opens streak details. The top-right paper logo opens project details. The Create plus makes a small random 90° turn about every half minute. Study sets, folders, currencies, Shop purchases, streak progress, and equipped looks are saved in this browser. Cover images, page backgrounds, and PDF attachments use the browser’s local file storage.

Click a study set to start studying right away. Lesson sets guide you through lesson content, its related questions, and a one-at-a-time animated reward reveal before moving to the next lesson. Finishing a lesson earns 25 Study Coins; completing the course adds a 100-coin bonus. At the course finish, Star Tokens are awarded for 50%+, Gold Stars for 75%+, and Crown Stars for 90%+ based on guided question answers, using the course’s star payout. Double-click or right-click a set for its options and editing tools. No XP is used.

Open Info to see grade ranges. Use a set’s menu to export one set, or open Settings to export the full library.

Built with HTML, CSS, and JavaScript. No installation or server is required.
